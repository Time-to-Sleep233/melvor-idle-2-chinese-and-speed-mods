@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0diagnose.ps1" %*
set "_melvor_exit=%errorlevel%"
if not "%_melvor_exit%"=="0" echo 诊断未完成，请查看上方错误信息。
pause
exit /b %_melvor_exit%
