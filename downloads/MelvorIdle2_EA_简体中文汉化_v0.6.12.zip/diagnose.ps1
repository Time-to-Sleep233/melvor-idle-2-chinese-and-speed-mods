﻿param([string]$GameDir)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
if(-not (Test-Path -LiteralPath (Join-Path $root 'lib.ps1'))) {throw '请先完整解压 ZIP。'}
. (Join-Path $root 'lib.ps1')
$game=Get-MelvorGameDir -RequestedDir $GameDir
$lines=New-Object 'Collections.Generic.List[string]'
function Add-Line([string]$Text) {$lines.Add($Text); Write-Host $Text}
Add-Line 'Melvor Idle 2 EA 汉化运行诊断'
Add-Line ('检查目录 '+$game)
Add-Line ('Steam Build '+(Get-MelvorSteamBuildId $game))
try {Test-EaTranslation $root $game; Add-Line '安装文件和加载项检查通过'}
catch {Add-Line ('安装检查失败 '+$_.Exception.Message)}
$user=Get-MelvorUserDataDir
$statusPath=Join-Path $user 'melvor2_zh_ea_runtime.json'
if(Test-Path -LiteralPath $statusPath -PathType Leaf) {
    try {
        $status=Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8 | ConvertFrom-Json
        Add-Line ('上次启动记录 '+(Get-Item -LiteralPath $statusPath).LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))
        Add-Line ('游戏程序 '+$status.executable)
        Add-Line ('汉化版本 '+$status.version+'，加载 '+$status.translation_loaded)
        Add-Line ('补译和校对 '+$status.supplement_entries+'，数量名称 '+$status.plural_names+'，未补齐 '+$status.plural_unresolved)
        Add-Line ('中文词典 SHA256 '+$status.native_locale_sha256)
        Add-Line ('显示文本补丁 '+$status.display_data_loaded)
        Add-Line ('原游戏数据 SHA256 '+$status.original_data_sha256)
        Add-Line ('显示文本叠加后的数据 SHA256 '+$status.data_sha256)
    } catch {Add-Line ('运行记录读取失败 '+$_.Exception.Message)}
} else {Add-Line '没有 EA 汉化运行记录。先启动已安装汉化的游戏一次。'}
$log=Join-Path $user 'logs\godot.log'
if(Test-Path -LiteralPath $log -PathType Leaf) {
    foreach($line in (Get-Content -LiteralPath $log -Encoding UTF8 | Where-Object {$_ -match 'ZH_EA|zh_mod\.gd|Game Version|SCRIPT ERROR'} | Select-Object -Last 16)) {Add-Line $line}
}
$report=Join-Path $root ('EA汉化运行诊断_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.txt')
[IO.File]::WriteAllLines($report,$lines,(New-Object Text.UTF8Encoding($true)))
Write-Host ('报告位置 '+$report)
