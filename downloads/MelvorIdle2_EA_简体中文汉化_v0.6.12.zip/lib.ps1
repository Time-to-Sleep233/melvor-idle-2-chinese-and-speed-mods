﻿$ErrorActionPreference = 'Stop'

function Get-MelvorUserDataDir { return (Join-Path $env:APPDATA 'Games By Malcs\Melvor Idle 2') }

function Enter-MelvorModLock {
    param([string]$GameDir)
    $path=Join-Path $GameDir '.melvor2_mod.lock'
    Assert-PlainPath $path
    try {return [IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
    catch {throw '另一个模组安装/卸载操作正在运行，或游戏目录无法写入，请稍后重试。'}
}

function Get-MelvorSteamLibraries {
    $registry = Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue
    $roots = @($registry.SteamPath, 'C:\Program Files (x86)\Steam', 'C:\Program Files\Steam', 'D:\Steam', 'E:\Steam')
    $libraries = foreach ($root in $roots | Select-Object -Unique) {
        if (-not $root -or -not [IO.Directory]::Exists($root)) { continue }
        $root
        $vdf = [IO.Path]::Combine($root, 'steamapps', 'libraryfolders.vdf')
        if (-not [IO.File]::Exists($vdf)) { continue }
        try {
            $content = Get-Content -LiteralPath $vdf -Raw -Encoding UTF8 -ErrorAction Stop
            foreach ($match in [regex]::Matches($content, '"path"\s+"([^"]+)"')) {
                $library = $match.Groups[1].Value.Replace('\\', '\')
                # Steam retains entries for disconnected disks in libraryfolders.vdf.
                if ([IO.Directory]::Exists($library)) { $library }
            }
        } catch {
            Write-Verbose ('无法读取 Steam 库清单，继续检查其他库：' + $vdf + '。' + $_.Exception.Message)
        }
    }
    $libraries | Select-Object -Unique
}

function Get-MelvorEaManifest {
    param([string]$GameDir)
    try {
        $directory = Get-Item -LiteralPath $GameDir -ErrorAction Stop
        $common = $directory.Parent
        if ($common.Name -ne 'common' -or $common.Parent.Name -ne 'steamapps') { return $null }
        $path = [IO.Path]::Combine($common.Parent.FullName, 'appmanifest_3218350.acf')
        if (-not [IO.File]::Exists($path)) { return $null }
        $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
        $name = [regex]::Match($content, '"installdir"\s+"([^"\r\n]+)"')
        if ($name.Success -and $name.Groups[1].Value -ieq $directory.Name) { return $content }
    } catch {
        Write-Verbose ('无法读取此目录的 EA 清单：' + $GameDir + '。' + $_.Exception.Message)
    }
    return $null
}

function Get-MelvorSteamBuildId {
    param([string]$GameDir)
    $manifest=Get-MelvorEaManifest $GameDir
    if($manifest) {
        $match=[regex]::Match($manifest,'"buildid"\s+"([^"\r\n]+)"')
        if($match.Success) {return $match.Groups[1].Value}
    }
    return $null
}

function Get-MelvorGameDir {
    param([string]$RequestedDir)
    if ($RequestedDir) {
        $candidate = $RequestedDir.Trim().Trim('"')
        $item = Get-Item -LiteralPath $candidate -ErrorAction SilentlyContinue
        if ($item -and $item.Name -ieq 'Melvor2.exe' -and -not $item.PSIsContainer) { $candidate = $item.DirectoryName }
        $exe = [IO.Path]::Combine($candidate, 'Melvor2.exe')
        if (-not [IO.File]::Exists($exe)) { throw "找不到 Melvor2.exe：$candidate" }
        $resolved = (Resolve-Path -LiteralPath $candidate).Path
        if ((Get-MelvorEaManifest $resolved) -or (Get-ModFileHash -LiteralPath $exe).Hash -eq '770b22a1c5bf37ab4e3bee0ba8b396a8008ecaa8d970270c3e9ed6d07ceffd3b') { return $resolved }
        throw '无法确认该目录属于 Steam EA（AppID 3218350）。请从 Steam 的“浏览本地文件”找到 EA 游戏目录。'
    }
    $found = foreach ($library in @(Get-MelvorSteamLibraries)) {
        try {
            $steamapps = [IO.Path]::Combine($library, 'steamapps')
            $path = [IO.Path]::Combine($steamapps, 'appmanifest_3218350.acf')
            if (-not [IO.File]::Exists($path)) { continue }
            $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
            $name = [regex]::Match($content, '"installdir"\s+"([^"\r\n]+)"')
            if (-not $name.Success -or $name.Groups[1].Value -match '[\\/:]' -or $name.Groups[1].Value -in @('.', '..')) { continue }
            $candidate = [IO.Path]::Combine($steamapps, 'common', $name.Groups[1].Value)
            if ([IO.File]::Exists([IO.Path]::Combine($candidate, 'Melvor2.exe'))) {
                (Resolve-Path -LiteralPath $candidate -ErrorAction Stop).Path
            }
        } catch {
            Write-Verbose ('跳过当前不可读取的 Steam 库：' + $library + '。' + $_.Exception.Message)
        }
    }
    $candidates = @($found | Sort-Object -Unique)
    if ($candidates.Count -eq 1) { return $candidates[0] }
    if ($candidates.Count -gt 1) { $candidates | ForEach-Object { Write-Host $_ } }
    $manual = Read-Host '请输入 Steam EA 的 Melvor2.exe 所在目录'
    if ($manual) { return Get-MelvorGameDir -RequestedDir $manual }
    throw '找不到 Melvor Idle 2 EA 游戏目录。'
}

function Get-ModFileHash {
    param([string]$LiteralPath,[string]$Algorithm='SHA256')
    if($Algorithm -ne 'SHA256') {throw 'Only SHA256 is supported.'}
    $crypto=[Security.Cryptography.SHA256]::Create();$stream=$null
    try {
        $stream=[IO.File]::OpenRead($LiteralPath)
        return [pscustomobject]@{Hash=[BitConverter]::ToString($crypto.ComputeHash($stream)).Replace('-','')}
    } finally {if($null -ne $stream) {$stream.Dispose()};$crypto.Dispose()}
}

function Assert-PackageFile {
    param([string]$Path,[string]$ExpectedHash)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "缺少文件: $Path" }
    if ((Get-ModFileHash -LiteralPath $Path -Algorithm SHA256).Hash -ne $ExpectedHash) { throw "文件校验失败: $Path" }
}

function Get-AutoloadValues {
    param([string]$Text,[string]$Name)
    $section = ''
    foreach ($line in ($Text -split '\r?\n')) {
        if ($line -cmatch '^\s*\[([^\]]+)\]\s*(?:;.*)?$') { $section=$Matches[1]; continue }
        if ($section -ceq 'autoload' -and $line -cmatch ('^\s*'+[regex]::Escape($Name)+'\s*=')) {
            if ($line -cnotmatch ('^\s*'+[regex]::Escape($Name)+'\s*=\s*"([^"]+)"\s*(?:;.*)?$')) { throw "无法解析 autoload 项 $Name，请检查 override.cfg。" }
            $Matches[1]
        }
    }
}

function Merge-AutoloadEntry {
    param([string]$ExistingText,[string]$Name,[string]$ManagedPath,[string]$Marker,[string[]]$AllowedExistingPaths=@())
    $allowed = @($ManagedPath,$ManagedPath.TrimStart('*'))+$AllowedExistingPaths+@($AllowedExistingPaths | ForEach-Object {$_.TrimStart('*')})
    foreach ($value in @(Get-AutoloadValues $ExistingText $Name)) {
        if ($value -notin $allowed) { throw "autoload 名称 $Name 已由其他模组使用，拒绝覆盖: $value" }
    }
    $lines=[Collections.Generic.List[string]]::new()
    if ($ExistingText) { foreach($line in ($ExistingText -split '\r?\n')) { $lines.Add($line) } }
    $section='';$indices=[Collections.Generic.List[int]]::new();$autoload=-1
    for($i=0;$i -lt $lines.Count;$i++) {
        if($lines[$i] -cmatch '^\s*\[([^\]]+)\]\s*(?:;.*)?$') { $section=$Matches[1];if($section -ceq 'autoload'){$autoload=$i};continue }
        if($section -ceq 'autoload' -and $lines[$i] -cmatch ('^\s*'+[regex]::Escape($Name)+'\s*=')) {$indices.Add($i)}
    }
    $managedLine=$Name+'="'+$ManagedPath+'"'
    if($indices.Count -gt 0) {$lines[$indices[0]]=$managedLine;for($i=$indices.Count-1;$i -ge 1;$i--){$lines.RemoveAt($indices[$i])}}
    elseif($autoload -ge 0) {$lines.Insert($autoload+1,$managedLine)}
    else {$lines.Add('');$lines.Add('[autoload]');$lines.Add($managedLine)}
    if(-not ($lines | Where-Object {$_ -eq $Marker})) {$lines.Insert(0,$Marker)}
    return (($lines -join "`r`n").TrimEnd()+"`r`n")
}

function Remove-AutoloadEntry {
    param([string]$ExistingText,[string]$Name,[string[]]$ManagedPaths,[string]$Marker)
    $result=[Collections.Generic.List[string]]::new();$section=''
    foreach($line in ($ExistingText -split '\r?\n')) {
        if($line -cmatch '^\s*\[([^\]]+)\]\s*(?:;.*)?$') {$section=$Matches[1]}
        if($line -eq $Marker) {continue}
        $remove=$false
        if($section -ceq 'autoload') {foreach($path in $ManagedPaths) {if($line -cmatch ('^\s*'+[regex]::Escape($Name)+'\s*=\s*"'+'\*?'+[regex]::Escape($path.TrimStart('*'))+'"\s*(?:;.*)?$')) {$remove=$true;break}}}
        if(-not $remove) {$result.Add($line)}
    }
    for($i=$result.Count-1;$i -ge 0;$i--) {
        if($result[$i] -cnotmatch '^\s*\[autoload\]\s*(?:;.*)?$') {continue}
        $next=$i+1
        while($next -lt $result.Count -and $result[$next].Trim() -eq '') {$next++}
        if($next -ge $result.Count -or $result[$next] -cmatch '^\s*\[') {$result.RemoveAt($i)}
    }
    $text=($result -join "`r`n").Trim()
    if($text) {return ($text+"`r`n")}
    return ''
}

function Assert-PlainPath {
    param([string]$Path,[switch]$Recursive)
    $current=[IO.Path]::GetFullPath($Path)
    while($current) {
        if(Test-Path -LiteralPath $current) {
            if((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw "目标路径含目录链接，拒绝修改: $current"}
        }
        $parent=Split-Path $current -Parent
        if(-not $parent -or $parent -eq $current) {break}
        $current=$parent
    }
    if($Recursive -and (Test-Path -LiteralPath $Path -PathType Container)) {
        foreach($item in (Get-ChildItem -LiteralPath $Path -Recurse -Force)) {
            if($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw "模组目录含链接，拒绝递归修改: $($item.FullName)"}
        }
    }
}

function Remove-ModTarget {
    param([string]$Path,[string]$Root)
    $full=[IO.Path]::GetFullPath($Path);$prefix=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
    if(-not $full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {throw "目标超出允许目录: $full"}
    Assert-PlainPath $full -Recursive
    if(Test-Path -LiteralPath $full) {Remove-Item -LiteralPath $full -Recurse -Force}
}

function Write-ModAtomicText {
    param([string]$Path,[string]$Text)
    $temporary=$Path+'.new_'+[guid]::NewGuid().ToString('N')
    try {
        [IO.File]::WriteAllText($temporary,$Text,(New-Object Text.UTF8Encoding($false)))
        if(Test-Path -LiteralPath $Path) {[IO.File]::Replace($temporary,$Path,[System.Management.Automation.Language.NullString]::Value)}
        else {[IO.File]::Move($temporary,$Path)}
    } finally {if(Test-Path -LiteralPath $temporary) {Remove-Item -LiteralPath $temporary -Force}}
}

function Get-ModOverrideText {
    param([string]$Path)
    if(Test-Path -LiteralPath $Path) {
        if(-not (Test-Path -LiteralPath $Path -PathType Leaf)) {throw "配置路径不是文件: $Path"}
        return Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    }
    return ''
}

function Assert-ModOwned {
    param([string]$ModDir,[string]$ModId)
    Assert-PlainPath $ModDir -Recursive
    if(Test-Path -LiteralPath $ModDir) {
        $owned=$false
        try {$owned=(Get-Content -LiteralPath (Join-Path $ModDir 'version.json') -Raw -Encoding UTF8 | ConvertFrom-Json).id -eq $ModId} catch {}
        if(-not $owned) {throw "目录不属于本模组，拒绝修改: $ModDir"}
    }
}

function Invoke-ModTransaction {
    param([string]$GameDir,[string[]]$Paths,[scriptblock]$Action)
    Assert-PlainPath $GameDir
    $transaction=Join-Path $GameDir ('.melvor2_transaction_'+[guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $transaction | Out-Null
    $snapshots=@();$clean=$false;$actionStarted=$false
    try {
        foreach($path in ($Paths | Select-Object -Unique)) {
            Assert-PlainPath $path -Recursive
            $exists=Test-Path -LiteralPath $path
            $copy=Join-Path $transaction ('snapshot_'+$snapshots.Count)
            $snapshots+=@{Path=$path;Backup=$copy;Exists=$exists}
            if($exists) {Copy-Item -LiteralPath $path -Destination $copy -Recurse -Force}
        }
        $actionStarted=$true
        & $Action $transaction
        $clean=$true
    } catch {
        $original=$_;$rollbackErrors=@()
        foreach($snapshot in $(if($actionStarted){$snapshots}else{@()})) {
            try {
                # If copying a snapshot failed before a backup existed, no action ran.
                if($snapshot.Exists -and -not (Test-Path -LiteralPath $snapshot.Backup)) {continue}
                $same=$false
                if($snapshot.Exists -and (Test-Path -LiteralPath $snapshot.Backup -PathType Leaf) -and (Test-Path -LiteralPath $snapshot.Path -PathType Leaf)) {
                    $same=(Get-ModFileHash -LiteralPath $snapshot.Backup).Hash -eq (Get-ModFileHash -LiteralPath $snapshot.Path).Hash
                }
                if($same) {continue}
                Remove-ModTarget $snapshot.Path (Split-Path $snapshot.Path -Parent)
                if($snapshot.Exists) {Copy-Item -LiteralPath $snapshot.Backup -Destination $snapshot.Path -Recurse -Force}
            } catch {$rollbackErrors+= $_.Exception.Message}
        }
        if($rollbackErrors.Count) {throw "操作失败: $($original.Exception.Message)。回滚未完成，备份保留在 $transaction。$($rollbackErrors -join '；')"}
        $clean=$true
        throw $original
    } finally {
        if($clean -and (Test-Path -LiteralPath $transaction)) {
            try {Remove-ModTarget $transaction $GameDir} catch {Write-Warning "操作已完成，临时备份保留在 $transaction"}
        }
    }
}

$EaModId='melvor2_zh_cn'
$EaAutoload='ZhMod'
$EaPath='*res://mods/melvor2_zh_cn/zh_mod.gd'
$EaMarker='; Melvor Idle 2 zh_CN mod - managed by installer'

function Read-EaPackageManifest {
    param([string]$PackageRoot)
    $path=Join-Path $PackageRoot 'manifest.json'
    if(-not (Test-Path -LiteralPath $path -PathType Leaf)) {throw '请把整个 ZIP 全部解压，再运行安装程序。'}
    $manifest=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if($manifest.steam_appid -ne '3218350' -or -not $manifest.files) {throw '汉化包清单无效，请重新下载。'}
    return $manifest
}

function Test-EaPayload {
    param([string]$Root,$Manifest)
    $modRoot=Join-Path $Root 'mods\melvor2_zh_cn'
    $names=@('zh_mod.gd','ea_language_patch.json','version.json')
    foreach($name in $names) {
        $key='mods/melvor2_zh_cn/'+$name
        $entry=$Manifest.files.PSObject.Properties[$key]
        if(-not $entry) {throw "清单缺少文件：$key"}
        $file=Join-Path $modRoot $name
        if(-not (Test-Path -LiteralPath $file -PathType Leaf)) {throw "缺少 $name，请确认 ZIP 已全部解压。"}
        Assert-PackageFile $file $entry.Value.sha256
        if((Get-Item -LiteralPath $file).Length -ne $entry.Value.size) {throw "文件大小校验失败：$file"}
    }
}

function Assert-EaGameStopped {
    if(Get-Process -Name Melvor2 -ErrorAction SilentlyContinue) {throw '请完全退出 Melvor Idle 2 后重试。'}
}

function Install-EaTranslation {
    param([string]$PackageRoot,[string]$GameDir,[switch]$NextLaunch)
    $manifest=Read-EaPackageManifest $PackageRoot
    $files=Join-Path $PackageRoot 'files'
    Test-EaPayload $files $manifest
    $override=Join-Path $GameDir 'override.cfg'
    $modDir=Join-Path $GameDir 'mods\melvor2_zh_cn'
    Assert-ModOwned $modDir $EaModId
    $before=Get-ModOverrideText $override
    $updated=Merge-AutoloadEntry $before $EaAutoload $EaPath $EaMarker @('*user://zh_mod.gd')
    if($NextLaunch -and ($updated -cne $before -or -not (Test-Path -LiteralPath $modDir -PathType Container))) {
        throw '仅可为已安装的 EA 汉化预置文件。首次安装请退出游戏。'
    }
    $targets=@($modDir)
    if($updated -cne $before){$targets+=$override}
    Invoke-ModTransaction $GameDir $targets {
        param($transaction)
        $stage=Join-Path $transaction 'payload'
        New-Item -ItemType Directory -Path $stage | Out-Null
        foreach($name in @('zh_mod.gd','ea_language_patch.json','version.json')) {
            $file=Join-Path $files ('mods\melvor2_zh_cn\'+$name)
            Copy-Item -LiteralPath $file -Destination (Join-Path $stage $name)
            Assert-PackageFile (Join-Path $stage $name) $manifest.files.PSObject.Properties['mods/melvor2_zh_cn/'+$name].Value.sha256
        }
        $mods=Split-Path $modDir -Parent
        New-Item -ItemType Directory -Path $mods -Force | Out-Null
        Remove-ModTarget $modDir $mods
        Move-Item -LiteralPath $stage -Destination $modDir
        if($updated -cne $before){Write-ModAtomicText $override $updated}
    }
}

function Test-EaTranslation {
    param([string]$PackageRoot,[string]$GameDir)
    $manifest=Read-EaPackageManifest $PackageRoot
    $values=@(Get-AutoloadValues (Get-ModOverrideText (Join-Path $GameDir 'override.cfg')) $EaAutoload)
    if($values.Count -ne 1 -or $values[0] -cne $EaPath) {throw 'EA 汉化加载项缺失或路径不匹配。'}
    Test-EaPayload $GameDir $manifest
    Write-Host ('EA 汉化安装文件检查通过 '+$manifest.version) -ForegroundColor Green
    Write-Host ('游戏目录 '+$GameDir)
    Write-Host ('Steam Build '+(Get-MelvorSteamBuildId $GameDir))
}

function Uninstall-EaTranslation {
    param([string]$GameDir)
    $modDir=Join-Path $GameDir 'mods\melvor2_zh_cn'
    $versionPath=Join-Path $modDir 'version.json'
    if(-not (Test-Path -LiteralPath $versionPath -PathType Leaf)) {return}
    Assert-ModOwned $modDir $EaModId
    $version=Get-Content -LiteralPath $versionPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if($version.steam_appid -ne '3218350') {throw '当前目录中的汉化属于其他版本，请用其对应卸载包。'}
    $override=Join-Path $GameDir 'override.cfg'
    $updated=Remove-AutoloadEntry (Get-ModOverrideText $override) $EaAutoload @($EaPath) $EaMarker
    Invoke-ModTransaction $GameDir @($modDir,$override) {
        param($transaction)
        if($updated.Trim()) {Write-ModAtomicText $override $updated}
        else {Remove-ModTarget $override $GameDir}
        Remove-ModTarget $modDir (Split-Path $modDir -Parent)
    }
}
