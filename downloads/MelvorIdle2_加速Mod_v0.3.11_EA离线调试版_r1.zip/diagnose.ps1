﻿param([string]$GameDir)
$ErrorActionPreference='Stop'
$PackageRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
if(-not (Test-Path -LiteralPath (Join-Path $PackageRoot 'lib.ps1'))) {throw '请先完整解压整个 ZIP，再运行诊断。'}
. (Join-Path $PackageRoot 'lib.ps1')
$game=Get-MelvorGameDir -RequestedDir $GameDir
$lines=New-Object 'Collections.Generic.List[string]'
function Add-DiagnosticLine([string]$Text) {$lines.Add($Text);Write-Host $Text}
Add-DiagnosticLine 'Melvor Idle 2 加速 Mod 运行诊断（只读检查，不修改游戏或存档）'
Add-DiagnosticLine ('检查时间: '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
Add-DiagnosticLine ('Steam EA 游戏目录: '+$game)
$manifest=Get-Content -LiteralPath (Join-Path $PackageRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$build=Get-MelvorSteamBuildId $game
Add-DiagnosticLine ('Steam Build: '+$(if($build){$build}else{'未找到 Steam 清单，可能是非标准目录'}))
Add-DiagnosticLine ('本包已实测 Build: '+$manifest.steam_buildid)
if($build -ne $manifest.steam_buildid) {Add-DiagnosticLine '版本提示（不阻止安装）: 当前 Build 未经本包完整游戏实测；运行时仍需检查接口。'}
try {
    Test-MelvorModInstallation -PackageRoot $PackageRoot -GameDir $game -ModId 'melvor2_speed' -Name 'SpeedMod' -AllowUnsupportedVersion
    Add-DiagnosticLine ('安装文件与 autoload: 通过 '+$manifest.version)
} catch {Add-DiagnosticLine ('安装文件与 autoload: 未通过；'+$_.Exception.Message)}
$versionPath=Join-Path $game 'mods\melvor2_speed\version.json'
if(Test-Path -LiteralPath $versionPath) {
    try {$version=Get-Content -LiteralPath $versionPath -Raw -Encoding UTF8 | ConvertFrom-Json;Add-DiagnosticLine ('实际文件版本: '+$version.version)}
    catch {Add-DiagnosticLine '实际文件版本: version.json 读取失败'}
}
$user=Get-MelvorUserDataDir
$statusPath=Join-Path $user 'melvor2_speed_runtime.json'
if(Test-Path -LiteralPath $statusPath) {
    try {
        $status=Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8 | ConvertFrom-Json
        Add-DiagnosticLine ('上次运行记录时间: '+(Get-Item -LiteralPath $statusPath).LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))
        Add-DiagnosticLine ('上次加载版本: '+$status.version)
        Add-DiagnosticLine ('上次启动程序: '+$status.executable)
        if([IO.Path]::GetFullPath($status.executable) -ine [IO.Path]::GetFullPath((Join-Path $game 'Melvor2.exe'))) {
            Add-DiagnosticLine '注意: 上次启动程序与当前检查目录不同，可能启动了另一份游戏。'
        }
        Add-DiagnosticLine ('初始化完成: '+$status.initialized+'；在线接口通过: '+$status.online_supported+'；当前暂缓: '+$status.suspended)
        Add-DiagnosticLine ('设定倍率: '+$status.multiplier+'；引擎物理频率: '+$status.physics_ticks)
        Add-DiagnosticLine ('当前在角色界面: '+$status.active_game_view+'；额外离线加速: '+$status.offline_supported)
        if($status.offline_reason) {Add-DiagnosticLine $status.offline_reason}
        if($status.exit_record_unix -gt 0) {
            $exitAt=[DateTimeOffset]::FromUnixTimeSeconds([long]$status.exit_record_unix).ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss')
            Add-DiagnosticLine ('上次正常退出: '+$exitAt+'；记录倍率: '+$status.exit_multiplier+' 倍；等待匹配角色: '+$status.offline_waiting_for_character)
        }
        if($status.offline_result -and $null -ne $status.offline_result.actual_seconds) {
            $info=$status.offline_result
            Add-DiagnosticLine ('最近一次读档离线: 实际 '+$info.actual_seconds+' 秒 × '+$info.multiplier+'；请求 '+$info.requested_seconds+' 秒。')
            Add-DiagnosticLine ('角色上限 '+$info.cap_seconds+' 秒；交给原生结算的目标 '+$info.target_seconds+' 秒。')
        }
        Add-DiagnosticLine ('识别到的数据包: '+$(if($status.data_path){$status.data_path}else{'无记录或未识别'}))
        Add-DiagnosticLine ('数据 SHA256: '+$status.data_hash)
        Add-DiagnosticLine ('原生 DLL SHA256: '+$status.native_hash)
        Add-DiagnosticLine '上述为上次写入的记录，不能单独证明本次启动或实际玩法已加速。'
    } catch {Add-DiagnosticLine ('运行记录读取失败: '+$_.Exception.Message)}
} else {Add-DiagnosticLine '没有加速 Mod 运行记录：请重启这份游戏；也可能脚本未加载或在初始化前报错。'}
$log=Join-Path $user 'logs\godot.log'
if(Test-Path -LiteralPath $log) {
    Add-DiagnosticLine ('当前 godot.log 修改时间: '+(Get-Item -LiteralPath $log).LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))
    $matches=@(Get-Content -LiteralPath $log -Encoding UTF8 | Where-Object {$_ -match 'SPEED_MOD|SPEED_OFFLINE|speed_mod\.gd|SCRIPT ERROR|Parse Error'} | Select-Object -Last 24)
    if($matches.Count) {Add-DiagnosticLine '当前日志相关行:';foreach($line in $matches){Add-DiagnosticLine $line}}
    else {Add-DiagnosticLine '当前日志没有加速 Mod 标记，安装文件存在仍不能证明脚本已经加载。'}
} else {Add-DiagnosticLine '未找到当前 godot.log。'}
$report=Join-Path $PackageRoot ('加速Mod诊断_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.txt')
try {
    [IO.File]::WriteAllLines($report,$lines,(New-Object Text.UTF8Encoding($true)))
    Write-Host ('诊断已保存: '+$report)
    Write-Host '报告含本地路径；反馈前可遮盖用户名和个人路径。'
} catch {Write-Warning ('无法保存诊断报告: '+$_.Exception.Message+'。请复制上方输出。')}
