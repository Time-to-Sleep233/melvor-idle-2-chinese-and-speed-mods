extends Node

const VERSION := "0.6.14"
const BASE_DATA := "res://Data/Packages/MelvorBase.json"
const NATIVE_ZH := "res://Locale/zh_CN.po"
const PATCH_FILE := "res://mods/melvor2_zh_cn/ea_language_patch.json"
const STATUS_FILE := "user://melvor2_zh_ea_runtime.json"
const PLURAL_NAME := &"PluralName"
const MASTERY_GUILD_BONUS_SCENE := "res://Components/MasteryGuild/mastery_guild_bonus_view.tscn"
const TRACKER_EXPERIENCE_SCENE := "res://Components/Trackers/tracker_experience_view.tscn"
const GAME_FOOTER_SCENE := "res://GameMenus/Footer/game_footer.tscn"
const FOOTER_COUNTDOWN_PATH := ^"PanelContainer/ExperienceContainer/TimeToLevelContainer/HBoxContainer/LevelContainer/TimeToLevelMargins/TimeToLevel"
const AGILITY_OBSTACLE_SCENE := "res://Entities/Agility/agility_obstacle_view.tscn"
const QUEST_BODY_SCENES := [
	"res://Entities/Quests/system_dialogue_container.tscn",
	"res://Entities/Quests/npc_dialogue_container.tscn",
	"res://Entities/Quests/player_dialogue_container.tscn",
]
const OBSTACLE_STATUS := {
	"Waiting": "[b]等待中[/b]",
	"Attempting": "[b][color=aqua]挑战中[/color][/b]",
	"Success": "[b][color=green]成功[/color][/b]",
	"Failed": "[b][color=orange_red]失败[/color][/b]",
	"Yeeted": "[b][color=grey]已移除[/color][/b]",
	"Skipped": "[b][color=orange]已跳过[/color][/b]",
}
enum UiRole { GENERAL, QUEST_SUMMARY, QUEST_DIALOGUE, QUEST_GOAL, OBSTACLE_STATE, CLEAR_HISTORY, CLEAR_CONDITION, CLEAR_PLOT }
# "Clear" is also a weather name in the game's native dictionary. Scope actions
# to the control and its owning scene; never replace the weather or arbitrary text.
const CLEAR_SCENES := {
	"res://Components/CombatLootHistory/enemy_history_panel.tscn": UiRole.CLEAR_HISTORY,
	"res://Components/ThievingLootHistory/thieving_history_panel.tscn": UiRole.CLEAR_HISTORY,
	"res://Components/ActionUntilX/stop_option_provider_view.tscn": UiRole.CLEAR_CONDITION,
	"res://Entities/Farming/farming_plot_view.tscn": UiRole.CLEAR_PLOT,
}
const UI_BATCH := 80
const UI_BUDGET_USEC := 1200
const DYNAMIC_LABELS := {
	"Regrowing:": "再生中：",
	"Regrows:": "再生次数：",
	"Regrow Interval:": "再生间隔：",
	"Damage on Fail:": "失败伤害：",
	"Max Hit:": "最大伤害：",
	"Perception:": "感知：",
	"Fortune:": "幸运：",
	"Stealth:": "隐匿：",
	"Success Chance:": "成功几率：",
	"Evasion Rating:": "躲避值：",
	"Accuracy Rating:": "精准值：",
	"Magic Damage:": "魔法伤害：",
}

var _native_locale: Translation
var _patch_count: int = 0
var _plural_count: int = 0
var _plural_unresolved: int = 0
var _ui_controls: Dictionary = {}
var _ui_roles: Dictionary = {}
var _obstacle_statuses: Dictionary = {}
var _plain_quest_text: Dictionary = {}
var _ui_batch: Array = []
var _ui_index: int = 0
var _ui_delay: float = 0.0
var _loading_owner: WeakRef
var _has_loading_state: bool = false
var _tags := RegEx.new()
var _level := RegEx.new()
var _minutes := RegEx.new()
var _hours := RegEx.new()
var _seconds := RegEx.new()
var _days := RegEx.new()
var _unit_re := RegEx.new()
var _words := RegEx.new()
var _short_time := RegEx.new()
var _templates: Dictionary = {}
var _text_cache: Dictionary = {}
var _text_data_loaded := false
var _original_data_hash := ""


func _ready() -> void:
	if not FileAccess.file_exists(BASE_DATA) or not ResourceLoader.exists(NATIVE_ZH, "Translation"):
		push_warning("ZH_EA: EA language resources are unavailable")
		_write_status(false)
		return
	_native_locale = ResourceLoader.load(NATIVE_ZH, "Translation") as Translation
	if _native_locale == null or _native_locale.locale != "zh_CN":
		push_warning("ZH_EA: Could not load the Simplified Chinese translation")
		_write_status(false)
		return

	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(PATCH_FILE))
	if parsed is Dictionary and parsed.get("entries") is Array and parsed.get("plural_names") is Array:
		_apply_text_patches(parsed["entries"])
		_add_plural_names(parsed["plural_names"])
		_register_numeric_templates(parsed.get("numeric_templates", []))
		if parsed.get("plain_quest_text") is Dictionary:
			_plain_quest_text = parsed["plain_quest_text"]
		_original_data_hash = FileAccess.get_sha256(BASE_DATA)
		if parsed.get("display_data") is Dictionary:
			_text_data_loaded = _mount_display_data(parsed["display_data"])
	else:
		push_warning("ZH_EA: Supplement unavailable; loaded bundled Chinese only")

	var domain := TranslationServer.get_or_add_domain("")
	if not domain.has_translation(_native_locale):
		TranslationServer.add_translation(_native_locale)
	# Use the display translation domain without changing C# format culture.
	domain.set_locale_override("zh_CN")
	_tags.compile("\\[[^\\]\\r\\n]+\\]")
	_level.compile("\\bLevel[ \\t]+(?=[0-9])")
	_minutes.compile("\\b([0-9]+)[ \\t]+minutes?\\b")
	_hours.compile("\\b([0-9]+)[ \\t]+hours?\\b")
	_seconds.compile("\\b([0-9]+)[ \\t]+seconds?\\b")
	_days.compile("\\b([0-9]+)[ \\t]+days?\\b")
	_unit_re.compile("\\b(?:HP|XP|GP)\\b")
	_words.compile("[A-Za-z]{2,}")
	_short_time.compile("([0-9]+(?:\\.[0-9]+)?)([dhms])(?![A-Za-z0-9])")
	get_tree().node_added.connect(_track_ui_control)
	get_tree().node_removed.connect(_untrack_ui_control)
	print("ZH_EA: ready version=", VERSION, " locale=", domain.get_locale_override(),
		" edited=", _patch_count, " plural_names=", _plural_count, " unresolved=", _plural_unresolved,
		" dynamic_ui=true display_data=", _text_data_loaded)
	_write_status(true)


func _track_ui_control(node: Node) -> void:
	if node is RichTextLabel and node.name == &"TimeToLevel" and _is_footer_countdown(node):
		var update_slot := _reserve_footer_countdown_width.bind(node)
		if not node.theme_changed.is_connected(update_slot):
			node.theme_changed.connect(update_slot)
			update_slot.call_deferred()
	if node is RichTextLabel and node.name == &"CustomDescription":
		var owner_node := node.get_parent()
		if owner_node != null and owner_node.scene_file_path == MASTERY_GUILD_BONUS_SCENE:
			# Allow unspaced localized text to wrap; the enclosing list handles scrolling.
			node.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			node.scroll_active = false
	if node is Label or node is RichTextLabel or node is Button or node is OptionButton or node is LineEdit or node is TextEdit or node is TabBar or node is TabContainer or node is ItemList or node is PopupMenu:
		var id := node.get_instance_id()
		var role := _ui_role(node)
		if role == UiRole.OBSTACLE_STATE:
			_obstacle_statuses[id] = weakref(node)
			return
		_ui_controls[id] = weakref(node)
		if role != UiRole.GENERAL:
			_ui_roles[id] = role
		if role in [UiRole.CLEAR_HISTORY, UiRole.CLEAR_CONDITION, UiRole.CLEAR_PLOT]:
			_localize_clear_action(node as Button, role)


func _is_footer_countdown(label: RichTextLabel) -> bool:
	var ancestor := label.get_parent()
	while ancestor is Control:
		if ancestor.scene_file_path == TRACKER_EXPERIENCE_SCENE:
			if ancestor.get_node_or_null(FOOTER_COUNTDOWN_PATH) != label:
				return false
			var footer := ancestor.get_parent()
			while footer != null:
				if footer.scene_file_path == GAME_FOOTER_SCENE:
					return true
				footer = footer.get_parent()
			return false
		ancestor = ancestor.get_parent()
	return false


func _reserve_footer_countdown_width(label: RichTextLabel) -> void:
	if not is_instance_valid(label) or not label.is_inside_tree() or label.is_queued_for_deletion():
		return
	# The game writes compact durations whenever the estimate changes. The UI
	# pass then expands the units. Reserve the wider forms independently of
	# the current value, keeping the game's alignment, height, and fit_content.
	var normal := label.get_theme_font("normal_font")
	var bold := label.get_theme_font("bold_font")
	var normal_size := label.get_theme_font_size("normal_font_size")
	var bold_size := label.get_theme_font_size("bold_font_size")
	var digit := "0"
	var widest := 0.0
	for n in range(10):
		var sample := str(n)
		var width := bold.get_string_size(sample, HORIZONTAL_ALIGNMENT_LEFT, -1, bold_size).x
		if width > widest:
			digit = sample
			widest = width
	var two := digit.repeat(2)
	var three := digit.repeat(3)
	var duration_width := 0.0
	for sample: String in [three + " 天 " + two + " 小时 " + two + " 分钟", two + " 小时 " + two + " 分钟",
		two + " 分钟 " + two + " 秒", two + " 秒", ">999 天", "--h --m --s", "不到 " + two + " 秒"]:
		duration_width = maxf(duration_width, bold.get_string_size(sample, HORIZONTAL_ALIGNMENT_LEFT, -1, bold_size).x)
	var frame_width := normal.get_string_size("还需即可达到", HORIZONTAL_ALIGNMENT_LEFT, -1, normal_size).x
	var padding := label.get_theme_stylebox("normal").get_minimum_size().x
	var wanted := ceilf(maxf(70.0, frame_width + duration_width + padding + 2.0))
	if not is_equal_approx(label.custom_minimum_size.x, wanted):
		label.custom_minimum_size.x = wanted


func _seed_ui_controls(root: Node) -> void:
	_track_ui_control(root)
	for child in root.get_children():
		_seed_ui_controls(child)


func _ui_role(node: Node) -> UiRole:
	if node is Button and node.name in [&"ClearButton", &"ClearPlotButton"]:
		var ancestor := node.get_parent()
		while ancestor != null:
			if CLEAR_SCENES.has(ancestor.scene_file_path):
				var found: UiRole = CLEAR_SCENES[ancestor.scene_file_path]
				if (found == UiRole.CLEAR_PLOT) == (node.name == &"ClearPlotButton"):
					return found
				break
			ancestor = ancestor.get_parent()
	if node is Label and node.name == &"QuestSynopsis" and node.get_parent() is Control:
		return UiRole.QUEST_SUMMARY
	if not node is RichTextLabel or node.name not in [&"Dialogue", &"TextLabel", &"Status", &"TaskDescription"]:
		return UiRole.GENERAL
	var parent := node.get_parent()
	while parent is Control:
		var scene_path := parent.scene_file_path
		if node.name == &"Status":
			var script: Script = parent.get_script()
			if scene_path == AGILITY_OBSTACLE_SCENE or (script != null and script.resource_path.ends_with("/AgilityObstacleView.cs")):
				return UiRole.OBSTACLE_STATE
		if node.name == &"TaskDescription" and scene_path == "res://Entities/Quests/quest_task_goal_view.tscn":
			return UiRole.QUEST_GOAL
		if node.name in [&"Dialogue", &"TextLabel"] and scene_path in QUEST_BODY_SCENES:
			return UiRole.QUEST_DIALOGUE
		parent = parent.get_parent()
	return UiRole.GENERAL


func _untrack_ui_control(node: Node) -> void:
	var id := node.get_instance_id()
	_ui_controls.erase(id)
	_ui_roles.erase(id)
	_obstacle_statuses.erase(id)


func _process(delta: float) -> void:
	var scene := get_tree().current_scene
	if not is_instance_valid(scene) or not scene.is_node_ready() or _native_locale == null:
		return
	if _loading_owner == null or _loading_owner.get_ref() != scene:
		_loading_owner = weakref(scene)
		_seed_ui_controls(scene)
		_has_loading_state = false
		for property: Dictionary in scene.get_property_list():
			if property["name"] == &"IsLoadingState":
				_has_loading_state = scene.get("IsLoadingState") is bool
				break
	if _has_loading_state and scene.get("IsLoadingState"):
		return
	_localize_obstacle_statuses()
	if _ui_index >= _ui_batch.size():
		_ui_delay -= delta
		if _ui_delay > 0.0:
			return
		_ui_batch = _ui_controls.keys()
		_ui_index = 0
		_ui_delay = 0.35
	var started := Time.get_ticks_usec()
	var stop := mini(_ui_index + UI_BATCH, _ui_batch.size())
	while _ui_index < stop:
		var ref: WeakRef = _ui_controls.get(_ui_batch[_ui_index])
		_ui_index += 1
		if ref != null:
			var node: Node = ref.get_ref()
			if is_instance_valid(node) and not node.is_queued_for_deletion() and _ui_visible(node):
				_localize_dynamic_control(node)
		if Time.get_ticks_usec() - started >= UI_BUDGET_USEC:
			break


func _localize_obstacle_statuses() -> void:
	# These displays may change several times between normal UI passes at 50x.
	for id: int in _obstacle_statuses:
		var control: RichTextLabel = _obstacle_statuses[id].get_ref()
		if not is_instance_valid(control) or control.is_queued_for_deletion() or not control.is_visible_in_tree():
			continue
		var bbcode: String = OBSTACLE_STATUS.get(control.get_parsed_text(), "")
		if not bbcode.is_empty():
			control.clear()
			control.append_text(bbcode)


func _ui_visible(node: Node) -> bool:
	if node is Control:
		return node.is_visible_in_tree()
	return node is Window and node.visible


func _localize_dynamic_control(node: Node) -> void:
	if node is LineEdit or node is TextEdit:
		var placeholder: String = String(node.get("placeholder_text"))
		if not placeholder.is_empty():
			var translated_placeholder := _localize_dynamic(placeholder)
			if translated_placeholder != placeholder:
				node.set("placeholder_text", translated_placeholder)
	var role: UiRole = _ui_roles.get(node.get_instance_id(), UiRole.GENERAL)
	if role in [UiRole.CLEAR_HISTORY, UiRole.CLEAR_CONDITION, UiRole.CLEAR_PLOT]:
		_localize_clear_action(node as Button, role)
	if role in [UiRole.QUEST_SUMMARY, UiRole.QUEST_DIALOGUE, UiRole.QUEST_GOAL]:
		_prepare_quest_layout(node, role)
	if role == UiRole.QUEST_DIALOGUE:
		# The game populates these labels with append_text(), even when .text is empty.
		# Only replace known plain prose, leaving styled text and links intact.
		var dialog: String = node.get_parsed_text().strip_edges()
		var fallback: String = _plain_quest_text.get(dialog, "")
		if not fallback.is_empty():
			node.clear()
			node.add_text(fallback)
	elif node is Label or node is RichTextLabel or node is Button:
		var name_mask := String(node.name).to_lower()
		if name_mask not in ["playername", "player_name", "charactername", "savename", "username", "npcname"]:
			var source: String = node.get("text")
			if not source.is_empty():
				var localized: String = _plain_quest_text.get(source.strip_edges(), source) if role == UiRole.QUEST_SUMMARY else source
				localized = _localize_dynamic(localized)
				if localized != source:
					node.set("text", localized)
			elif node is RichTextLabel and node.name == &"InstructionLabel":
				var plain: String = node.get_parsed_text()
				if plain in ["Select an Area to get started.", "Select a Location to get started."]:
					node.text = _localize_dynamic(plain)
	if (node is OptionButton or node is ItemList or node is PopupMenu) and node.item_count <= 48:
		for index in range(node.item_count):
			var old: String = node.get_item_text(index)
			var translated := _localize_dynamic(old)
			if translated != old:
				node.set_item_text(index, translated)
	elif (node is TabBar or node is TabContainer) and node.get_tab_count() <= 48:
		for index in range(node.get_tab_count()):
			var old: String = node.get_tab_title(index)
			var translated := _localize_dynamic(old)
			if translated != old:
				node.set_tab_title(index, translated)
	if node is Control and not node.tooltip_text.is_empty():
		var tooltip := _localize_dynamic(node.tooltip_text)
		if tooltip != node.tooltip_text:
			node.tooltip_text = tooltip


func _localize_clear_action(button: Button, role: UiRole) -> void:
	# HoldForActionButton rebuilds .text from these exported values when the
	# input mode changes. Translate both states without touching input behavior.
	if role == UiRole.CLEAR_PLOT:
		if &"PressActionText" in button and str(button.get(&"PressActionText")) in ["Clear", "晴天"]:
			button.set(&"PressActionText", "清理田地")
		if &"HoldActionText" in button and str(button.get(&"HoldActionText")) in ["Hold to Clear", "长按清空"]:
			button.set(&"HoldActionText", "长按清理田地")
		if button.text in ["Hold to Clear", "长按清空"]:
			button.text = "长按清理田地"
		if button.text in ["Clear", "晴天"]:
			button.text = "清理田地"
	elif button.text in ["Clear", "晴天"]:
		button.text = "清除记录" if role == UiRole.CLEAR_HISTORY else "清除条件"


func _prepare_quest_layout(node: Control, role: UiRole) -> void:
	var width: float
	if node is Label:
		width = (node.get_parent() as Control).size.x
		node.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		node.clip_text = false
		node.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
		node.max_lines_visible = -1
	else:
		var parent := node.get_parent()
		while parent is Control and not parent is ScrollContainer:
			parent = parent.get_parent()
		if not parent is ScrollContainer:
			return
		var scroll := parent as ScrollContainer
		var edge := scroll.get_global_rect().end.x - scroll.get_v_scroll_bar().get_combined_minimum_size().x
		width = edge - node.get_global_rect().position.x - 8.0
		if role == UiRole.QUEST_DIALOGUE and node.name == &"Dialogue":
			# Player and NPC speech bubbles have a native fixed panel width.
			width = minf(width, 410.0)
		node.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		node.fit_content = true
		node.scroll_active = false
	if width > 48.0 and not is_equal_approx(node.custom_maximum_size.x, width):
		node.custom_maximum_size.x = width


func _localize_dynamic(source: String) -> String:
	if source.is_empty() or source.length() > 12000:
		return source
	if _text_cache.has(source):
		return _text_cache[source]
	var result := _resolve_ui_text(source)
	if _text_cache.size() >= 4096:
		_text_cache.clear()
	_text_cache[source] = result
	return result


func _resolve_ui_text(source: String) -> String:
	# Chinese countdowns can contain only one-letter time units or BBCode tags.
	# Handle this exact translated template before the two-letter English-word shortcut.
	if source.strip_edges().begins_with("还需") and source.strip_edges().ends_with("即可达到"):
		return _expand_time(source)
	if _words.search(source) == null:
		return source
	var trimmed := source.strip_edges()
	var translated := String(_native_locale.get_message(trimmed))
	if not translated.is_empty() and translated != trimmed:
		return source.replace(trimmed, translated)
	var formatted := _resolve_numeric_template(trimmed)
	if formatted != trimmed:
		return source.replace(trimmed, formatted)
	if trimmed.begins_with("You were away for "):
		var elapsed := _localize_dynamic_fragment(trimmed.trim_prefix("You were away for "), false).trim_suffix(".")
		return "你离开了 " + _expand_time(elapsed) + "。"
	if trimmed.begins_with("Total 等级 ") or trimmed.begins_with("Total Level "):
		return source.replace("Total 等级 ", "总等级 ").replace("Total Level ", "总等级 ")
	var toolbelt := source.contains(" is equipped to ") and source.contains("toolbelt")
	var skill_experience := source.contains("Skill XP") or source.contains("Skill 经验") or source.contains("Technique XP")
	var needed := toolbelt or skill_experience or source.contains("Level ") or source.contains("Total ") \
		or _unit_re.search(source) != null or source.contains(" minute") or source.contains(" hour") \
		or source.contains(" second") or source.contains(" day")
	if not needed:
		for key: String in DYNAMIC_LABELS:
			if source.contains(key):
				needed = true
				break
	if not needed:
		return source
	var pieces := PackedStringArray()
	var position := 0
	var image_reference := false
	for tag: RegExMatch in _tags.search_all(source):
		var fragment := source.substr(position, tag.get_start() - position)
		pieces.append(fragment if image_reference else _localize_dynamic_fragment(fragment, toolbelt))
		var markup := tag.get_string()
		pieces.append(markup)
		if markup == "[/img]":
			image_reference = false
		elif markup.begins_with("[img"):
			image_reference = true
		position = tag.get_end()
	var tail := source.substr(position)
	pieces.append(tail if image_reference else _localize_dynamic_fragment(tail, toolbelt))
	return "".join(pieces)


func _expand_time(text: String) -> String:
	var units := {"d": "天", "h": "小时", "m": "分钟", "s": "秒"}
	var result := ""
	var start := 0
	for match: RegExMatch in _short_time.search_all(text):
		result += text.substr(start, match.get_start() - start)
		result += match.get_string(1) + " " + units[match.get_string(2)]
		start = match.get_end()
	return (result + text.substr(start)).replace("less than ", "不到 ")


func _localize_dynamic_fragment(text: String, toolbelt: bool) -> String:
	for key: String in DYNAMIC_LABELS:
		var target: String = DYNAMIC_LABELS[key]
		text = text.replace(key + " ", target).replace(key, target)
	text = text.replace("Skill XP", "技能经验").replace("Skill 经验", "技能经验").replace("Technique XP", "技巧经验")
	if toolbelt:
		text = text.replace(" is equipped to ", "已装备到").replace(" toolbelt", "工具带")
	if text.contains("Level "):
		text = _level.sub(text, "等级 ", true)
	if text.contains(" minute"):
		text = _minutes.sub(text, "$1 分钟", true)
	if text.contains(" hour"):
		text = _hours.sub(text, "$1 小时", true)
	if text.contains(" second"):
		text = _seconds.sub(text, "$1 秒", true)
	if text.contains(" day"):
		text = _days.sub(text, "$1 天", true)
	text = text.replace(" HP", " 生命值").replace(" XP", " 经验").replace(" GP", " 金币")
	if text.contains("Total 等级"):
		text = text.replace("Total 等级", "总等级")
	return text


func _register_numeric_templates(entries: Array) -> void:
	for entry: Array in entries:
		var pattern := RegEx.new()
		if pattern.compile(entry[1]) != OK:
			continue
		var bucket: Array = _templates.get_or_add(entry[0], [])
		bucket.append([pattern, entry[2]])


func _resolve_numeric_template(source: String) -> String:
	if source.length() > 480:
		return source
	var seen: Dictionary = {}
	for word: RegExMatch in _words.search_all(source):
		var anchor := word.get_string().to_lower()
		if seen.has(anchor) or not _templates.has(anchor):
			continue
		seen[anchor] = true
		for entry: Array in _templates[anchor]:
			var pattern: RegEx = entry[0]
			if pattern.search(source) != null:
				return pattern.sub(source, entry[1])
	return source


func _mount_display_data(data: Dictionary) -> bool:
	if data.get("source_sha256") != _original_data_hash or not data.get("operations") is Array:
		return false
	var original := FileAccess.get_file_as_bytes(BASE_DATA)
	var output := PackedByteArray()
	var offset := 0
	for item: Array in data["operations"]:
		var start := int(item[0])
		var end := int(item[1])
		if start < offset or end <= start or end > original.size():
			return false
		output.append_array(original.slice(offset, start))
		output.append_array(String(item[2]).to_utf8_buffer())
		offset = end
	output.append_array(original.slice(offset))
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(output)
	if hash.finish().hex_encode() != data.get("translated_sha256"):
		push_warning("ZH_EA: Local display text overlay checksum differs")
		return false
	var cache := ProjectSettings.globalize_path("user://melvor2_zh_ea_0.6.14_display")
	var raw_path := cache + "." + str(OS.get_process_id()) + ".json"
	var pack_path := cache + ".pck"
	var temporary_pack := cache + "." + str(OS.get_process_id()) + ".pck"
	var file := FileAccess.open(raw_path, FileAccess.WRITE)
	if file == null:
		return false
	file.store_buffer(output)
	file.close()
	var packer := PCKPacker.new()
	var result := packer.pck_start(temporary_pack)
	if result == OK:
		result = packer.add_file(BASE_DATA, raw_path)
	if result == OK:
		result = packer.flush()
	DirAccess.remove_absolute(raw_path)
	if result == OK:
		result = DirAccess.rename_absolute(temporary_pack, pack_path)
	if result != OK:
		DirAccess.remove_absolute(temporary_pack)
		push_warning("ZH_EA: Could not create local display text overlay")
		return false
	return ProjectSettings.load_resource_pack(pack_path, true)


func _apply_text_patches(entries: Array) -> void:
	for entry: Dictionary in entries:
		var source: StringName = entry["source"]
		var context: StringName = entry["context"]
		var previous: StringName = _native_locale.get_message(source, context)
		# A Steam update may supply a newer translation. Keep it when it differs
		# from the exact text the correction was written for.
		if previous != StringName(entry["expected"]) or previous == StringName(entry["translation"]):
			continue
		_native_locale.erase_message(source, context)
		if not String(entry.get("plural", "")).is_empty():
			_native_locale.add_plural_message(source, PackedStringArray([entry["translation"]]), context)
		else:
			_native_locale.add_message(source, entry["translation"], context)
		_patch_count += 1


func _add_plural_names(entries: Array) -> void:
	for entry: Dictionary in entries:
		var source: StringName = entry["source"]
		var plural: StringName = entry["plural"]
		var current := _native_locale.get_plural_message(source, plural, 2, PLURAL_NAME)
		if not current.is_empty() and current != source and current != plural:
			continue
		var translated: StringName = _native_locale.get_plural_message(source, plural, 2)
		if translated.is_empty() or translated == source or translated == plural:
			translated = _native_locale.get_message(source)
		if translated.is_empty() or translated == source or translated == plural:
			translated = entry["demo"]
		if translated.is_empty() or translated == source or translated == plural:
			_plural_unresolved += 1
			continue
		_native_locale.add_plural_message(source, PackedStringArray([String(translated)]), PLURAL_NAME)
		_plural_count += 1


func _write_status(loaded: bool) -> void:
	var record := {
		"version": VERSION, "executable": OS.get_executable_path(),
		"recorded_unix": int(Time.get_unix_time_from_system()), "translation_loaded": loaded,
		"supplement_entries": _patch_count, "plural_names": _plural_count,
		"dynamic_ui": loaded,
		"display_data_loaded": _text_data_loaded, "original_data_sha256": _original_data_hash,
		"plural_unresolved": _plural_unresolved, "data_sha256": FileAccess.get_sha256(BASE_DATA),
		"native_locale_sha256": FileAccess.get_sha256(NATIVE_ZH)
	}
	var pending := STATUS_FILE + ".tmp"
	var file := FileAccess.open(pending, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(record, "  "))
	file.close()
	DirAccess.rename_absolute(ProjectSettings.globalize_path(pending), ProjectSettings.globalize_path(STATUS_FILE))
