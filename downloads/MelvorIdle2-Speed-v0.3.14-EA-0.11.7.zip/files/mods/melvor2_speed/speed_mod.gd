extends Node

const VERSION := "0.3.14"
const EA_DATA_PATH := "res://Data/Packages/MelvorBase.json"
const STATUS_PATH := "user://melvor2_speed_runtime.json"
const CONFIG_PATH := "user://melvor2_speed.cfg"
const SPEEDS := [1.0, 2.0, 3.0, 5.0, 10.0, 20.0, 50.0]
const GAME_VIEW := "res://GameMenus/game_view.tscn"
const QUEST_DIALOGUE_VIEW := "res://Entities/Quests/quest_dialogue_view.tscn"
const VERSION_PATH := "res://mods/melvor2_speed/version.json"
const EXIT_SPEED_PATH := "user://melvor2_speed_exit.cfg"
const OFFLINE_KEYS := "melvor2_speed/offline/"
const CAP_HOURS := [24, 48, 72]
const DEFAULT_CAP_HOURS := 72
const BUTTON_TOP_MARGIN := 96.0
var _base_ticks_per_second := 60
var _base_max_physics_steps := 8
var _speed_multiplier := 2.0
var _button_visible := true
var _speed_button: Button
var _speed_panel: PanelContainer
var _cap_option: OptionButton
var _cap_hours := DEFAULT_CAP_HOURS
var _native_panel: Control
var _game_view: Node
var _game_view_content: CanvasItem
var _quest_dialogues: Dictionary = {}
var _sample_ticks := 0
var _sample_usec := 0
var _effective_speed := -1.0
var _engine_ready := false
var _applied_ticks := 60
var _applied_steps := 8
var _suspended := false
var _load_owner: WeakRef = null
var _load_property := false
var _data_path: String = ""
var _data_hash: String = ""
var _online_supported := false
var _native_hash := ""
var _offline_supported := false
var _offline_enabled := true
var _exit_multiplier := 1.0
var _exit_record_time := 0
var _offline_result: Dictionary = {}


func _ready() -> void:
	if FileAccess.file_exists(EA_DATA_PATH):
		_data_path = EA_DATA_PATH
		_data_hash = FileAccess.get_sha256(EA_DATA_PATH)
	var native_path := ProjectSettings.globalize_path("res://").path_join("data_GamesByMalcs.Melvor2_windows_x86_64/GamesByMalcs.Melvor2.dll")
	if FileAccess.file_exists(native_path):
		_native_hash = FileAccess.get_sha256(native_path)
	process_mode = Node.PROCESS_MODE_ALWAYS
	_base_ticks_per_second = Engine.physics_ticks_per_second
	_base_max_physics_steps = Engine.max_physics_steps_per_frame
	_load_speed()
	_load_exit_speed()
	_create_speed_button()
	get_tree().node_added.connect(_watch_game_control)
	get_tree().node_removed.connect(_forget_game_control)
	_sample_ticks = Engine.get_physics_frames()
	_sample_usec = Time.get_ticks_usec()
	call_deferred("_initialize_speed")
	print("SPEED_MOD: ready version=", VERSION, " data_path=", _data_path, " online_target=", _speed_multiplier)
	_write_runtime_status()
	if OS.get_environment("MELVOR2_SPEED_SELFTEST") == "1":
		call_deferred("_run_selftest")


func _initialize_speed() -> void:
	var main: Node = get_tree().current_scene
	if main == null or not main.is_node_ready():
		return
	# VersionOverlay._Ready initializes the game's Constants from the original
	# engine tick rate. Apply acceleration only after the main scene is ready.
	_engine_ready = true
	_apply_speed(_should_suspend())


func _game_is_loading() -> bool:
	var main := get_tree().current_scene
	if not is_instance_valid(main) or not main.is_node_ready():
		return true
	if _load_owner == null or _load_owner.get_ref() != main:
		_load_owner = weakref(main)
		_load_property = false
		_native_panel = null
		for entry in main.get_property_list():
			if entry.name == &"IsLoadingState":
				_load_property = main.get(&"IsLoadingState") is bool
			elif entry.name == &"Offline":
				_native_panel = main.get(&"Offline") as Control
		_online_supported = _load_property
		print("SPEED_MOD: online_interface=", _online_supported, " loading_property=", _load_property)
	return not _online_supported or bool(main.get(&"IsLoadingState"))


func _active_game_view() -> bool:
	return is_instance_valid(_game_view) and not _game_view.is_queued_for_deletion() and is_instance_valid(_game_view_content) and _game_view_content.is_visible_in_tree()


func _watch_game_control(node: Node) -> void:
	var content: CanvasItem
	if node.scene_file_path == GAME_VIEW:
		_game_view = node
		_game_view_content = node.get_node_or_null("MainContainer") as CanvasItem
		content = _game_view_content
	elif node is Control and node.scene_file_path == QUEST_DIALOGUE_VIEW:
		_quest_dialogues[node.get_instance_id()] = weakref(node)
		content = node
	if is_instance_valid(content) and not content.visibility_changed.is_connected(_update_button_visibility):
		content.visibility_changed.connect(_update_button_visibility)
		_update_button_visibility()


func _forget_game_control(node: Node) -> void:
	if is_instance_valid(_game_view) and node == _game_view:
		_game_view = null
		_game_view_content = null
		_update_button_visibility()
	elif _quest_dialogues.erase(node.get_instance_id()):
		_update_button_visibility()


func _update_button_visibility() -> void:
	var visible := _button_visible and _active_game_view()
	if visible:
		for reference: WeakRef in _quest_dialogues.values():
			var dialog: Control = reference.get_ref()
			if is_instance_valid(dialog) and dialog.is_visible_in_tree():
				visible = false
				break
	if _speed_panel.visible and not visible:
		_cap_option.get_popup().hide()
	_speed_panel.visible = visible


func _should_suspend() -> bool:
	return _game_is_loading() or not _active_game_view() or get_tree().paused or (is_instance_valid(_native_panel) and _native_panel.is_visible_in_tree())


func _process(_delta: float) -> void:
	_record_offline_settlement()
	if not _engine_ready:
		_initialize_speed()
	if _engine_ready:
		var suspended := _should_suspend()
		if suspended != _suspended:
			_apply_speed(suspended)
	var now: int = Time.get_ticks_usec()
	if now - _sample_usec >= 2000000:
		if _engine_ready and not _suspended:
			_effective_speed = float(Engine.get_physics_frames() - _sample_ticks) / (float(now - _sample_usec) / 1000000.0) / _base_ticks_per_second
		else:
			_effective_speed = -1.0
		_sample_ticks = Engine.get_physics_frames()
		_sample_usec = now
		_update_button()


func _input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if event.ctrl_pressed or event.alt_pressed or event.meta_pressed or event.shift_pressed or not _active_game_view():
		return
	var key: int = event.keycode if event.keycode != 0 else event.physical_keycode
	if key == KEY_F7 and _offline_supported:
		_toggle_offline()
	elif key == KEY_F8:
		_cycle_speed()
	elif key == KEY_F9:
		_button_visible = not _button_visible
		_update_button_visibility()
		_save_speed()
	else:
		return
	get_viewport().set_input_as_handled()


func _cycle_speed() -> void:
	_speed_multiplier = SPEEDS[(SPEEDS.find(_speed_multiplier) + 1) % SPEEDS.size()]
	_apply_speed(_should_suspend())
	_save_speed()


func _apply_speed(suspended: bool) -> void:
	if not _engine_ready:
		_update_button()
		return
	_speed_multiplier = _sanitize_speed(_speed_multiplier)
	_suspended = suspended
	var active_multiplier: float = 1.0 if _suspended else _speed_multiplier
	_applied_ticks = int(round(_base_ticks_per_second * active_multiplier))
	Engine.physics_ticks_per_second = _applied_ticks
	# Keep the original minimum render rate before Godot drops simulation time.
	# Scaling tick frequency alone makes 50x require 60 FPS (50 steps/frame).
	# With the native 8-step allowance scaled too, it still tolerates 7.5 FPS.
	_applied_steps = int(ceil(_base_max_physics_steps * active_multiplier))
	Engine.max_physics_steps_per_frame = _applied_steps
	_sample_ticks = Engine.get_physics_frames()
	_sample_usec = Time.get_ticks_usec()
	_effective_speed = -1.0
	_update_button()
	_update_button_visibility()
	_write_runtime_status()


func _write_runtime_status() -> void:
	var status := {
		"version": VERSION, "recorded_unix": int(Time.get_unix_time_from_system()),
		"executable": OS.get_executable_path(), "pid": OS.get_process_id(),
		"data_path": _data_path, "data_hash": _data_hash,
		"initialized": _engine_ready, "loading_interface": _load_property,
		"online_supported": _online_supported, "suspended": _suspended,
		"multiplier": _speed_multiplier, "physics_ticks": Engine.physics_ticks_per_second,
		"native_hash": _native_hash, "active_game_view": _active_game_view(),
		"offline_cap_hours": _cap_hours if _offline_supported else 0,
		"offline_supported": _offline_supported, "offline_enabled": _offline_enabled,
		"offline_reason": _offline_description(), "exit_multiplier": _exit_multiplier,
		"exit_record_unix": _exit_record_time,
		"offline_waiting_for_character": not String(ProjectSettings.get_setting(OFFLINE_KEYS + "exited_slot", "")).is_empty(),
		"offline_result": _offline_result
	}
	var temporary := STATUS_PATH + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(status, "  "))
	file.close()
	DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), ProjectSettings.globalize_path(STATUS_PATH))


func _update_button() -> void:
	if not is_instance_valid(_speed_button):
		return
	var suffix := " · 暂缓" if _suspended else (" · 高负载" if _speed_multiplier >= 20.0 else "")
	_speed_button.text = "速度 %d×%s" % [int(_speed_multiplier), suffix]
	var measured := "\n实测物理更新倍率 %.1f×" % _effective_speed if _effective_speed >= 0.0 else ""
	var interface_note := "\n缺少可识别的加载状态接口" if _engine_ready and not _online_supported else ""
	_speed_button.tooltip_text = "点击或按 F8 切换倍速。F9 显示或隐藏面板。" + measured + interface_note
	if is_instance_valid(_cap_option):
		var wanted := _cap_option.get_item_index(_cap_hours) if _offline_supported else 0
		if _cap_option.selected != wanted:
			_cap_option.select(wanted)
		_cap_option.tooltip_text = _offline_description()


func _create_speed_button() -> void:
	var layer := CanvasLayer.new()
	layer.name = "Melvor2SpeedLayer"
	layer.layer = 100
	add_child(layer)
	var anchor := Control.new()
	anchor.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(anchor)
	anchor.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_speed_panel = PanelContainer.new()
	_speed_panel.name = "Melvor2SpeedPanel"
	_speed_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color("#142035")
	panel_style.border_color = Color("#43536d")
	panel_style.set_border_width_all(1)
	panel_style.set_corner_radius_all(8)
	panel_style.content_margin_left = 6.0
	panel_style.content_margin_right = 6.0
	panel_style.content_margin_top = 5.0
	panel_style.content_margin_bottom = 5.0
	_speed_panel.add_theme_stylebox_override("panel", panel_style)
	anchor.add_child(_speed_panel)
	_speed_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_speed_panel.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_speed_panel.offset_left = -306.0
	_speed_panel.offset_right = -18.0
	_speed_panel.offset_top = BUTTON_TOP_MARGIN
	_speed_panel.offset_bottom = BUTTON_TOP_MARGIN + 44.0
	var row := HBoxContainer.new()
	row.name = "SpeedSettingsRow"
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 6)
	_speed_panel.add_child(row)

	_speed_button = Button.new()
	_speed_button.name = "Melvor2SpeedButton"
	_speed_button.custom_minimum_size = Vector2(115.0, 34.0)
	_speed_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_speed_button.focus_mode = Control.FOCUS_NONE
	_speed_button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	_speed_button.add_theme_font_size_override("font_size", 15)
	row.add_child(_speed_button)
	_speed_button.pressed.connect(_cycle_speed)

	_cap_option = OptionButton.new()
	_cap_option.name = "Melvor2OfflineCapOption"
	_cap_option.custom_minimum_size = Vector2(150.0, 34.0)
	_cap_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_cap_option.focus_mode = Control.FOCUS_NONE
	_cap_option.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	_cap_option.add_theme_font_size_override("font_size", 15)
	row.add_child(_cap_option)
	if _offline_supported:
		_cap_option.add_item("离线上限：原版", 24)
		_cap_option.add_item("离线上限：48 小时", 48)
		_cap_option.add_item("离线上限：72 小时", 72)
		_cap_option.item_selected.connect(_on_cap_item_selected)
	else:
		_cap_option.add_item("离线上限不可用", 0)
		_cap_option.disabled = true
	_speed_panel.hide()
	_update_button()


func _on_cap_item_selected(index: int) -> void:
	_select_cap(_cap_option.get_item_id(index))


func _sanitize_cap(value: Variant) -> int:
	if value is int and CAP_HOURS.has(value):
		return value
	return DEFAULT_CAP_HOURS


func _sync_offline_cap() -> void:
	# 24 means the game's native rule, not a replacement for native bonuses.
	var custom_ms := float(_cap_hours) * 3600000.0 if _offline_supported and _cap_hours != 24 else 0.0
	ProjectSettings.set_setting(OFFLINE_KEYS + "configured_cap_ms", custom_ms)


func _select_cap(hours: int) -> void:
	if not _offline_supported or not CAP_HOURS.has(hours):
		return
	_cap_hours = hours
	_sync_offline_cap()
	_save_speed()
	_update_button()
	_write_runtime_status()



func _sanitize_speed(value: Variant, fallback: float = 2.0) -> float:
	if not (value is float or value is int or (value is String and value.is_valid_float())):
		return fallback
	var number: float = float(value)
	if not is_finite(number) or not SPEEDS.has(number):
		return fallback
	return number


func _load_speed() -> void:
	var config := ConfigFile.new()
	var error := config.load(CONFIG_PATH)
	if error == ERR_FILE_NOT_FOUND:
		return
	if error != OK:
		push_warning("Speed Mod settings are invalid; defaults loaded")
		return
	_speed_multiplier = _sanitize_speed(config.get_value("speed", "multiplier", 2.0))
	var shown: Variant = config.get_value("speed", "button_visible", true)
	_button_visible = shown if shown is bool else true
	var follow: Variant = config.get_value("offline", "follow_exit", true)
	_offline_enabled = follow if follow is bool else true
	_cap_hours = _sanitize_cap(config.get_value("offline", "cap_hours", DEFAULT_CAP_HOURS))


func _save_speed() -> void:
	var config := ConfigFile.new()
	config.load(CONFIG_PATH)
	config.set_value("speed", "multiplier", _speed_multiplier)
	config.set_value("speed", "button_visible", _button_visible)
	config.set_value("offline", "follow_exit", _offline_enabled)
	config.set_value("offline", "cap_hours", _cap_hours)
	_save_config(config, CONFIG_PATH)


func _save_config(config: ConfigFile, path: String) -> void:
	var temporary := ProjectSettings.globalize_path(path + ".tmp")
	if config.save(temporary) != OK:
		push_warning("Speed Mod could not write " + path)
		return
	if DirAccess.rename_absolute(temporary, ProjectSettings.globalize_path(path)) != OK:
		push_warning("Speed Mod could not replace " + path + "; previous file retained")
		DirAccess.remove_absolute(temporary)


func _load_exit_speed() -> void:
	var version: Variant = JSON.parse_string(FileAccess.get_file_as_string(VERSION_PATH))
	_offline_supported = version is Dictionary and not _native_hash.is_empty() \
		and _native_hash == String(version.get("offline_patched_sha256", ""))
	var record := ConfigFile.new()
	var slot := ""
	if record.load(EXIT_SPEED_PATH) == OK:
		# Consume the file when a new process starts. An interrupted process
		# cannot reuse the previous session's exit multiplier on another launch.
		if DirAccess.remove_absolute(ProjectSettings.globalize_path(EXIT_SPEED_PATH)) == OK:
			if _offline_supported:
				var recorded_slot: Variant = record.get_value("exit", "slot", "")
				if recorded_slot is String and recorded_slot.length() == 36:
					slot = recorded_slot
					_exit_multiplier = _sanitize_speed(record.get_value("exit", "multiplier", 1.0), 1.0)
					var recorded_time: Variant = record.get_value("exit", "unix_time", 0)
					_exit_record_time = recorded_time if recorded_time is int else 0
		else:
			push_warning("Speed Mod could not consume the exit record; this launch uses native offline time")
	ProjectSettings.set_setting(OFFLINE_KEYS + "exited_slot", slot)
	_set_offline_resume_multiplier()
	_sync_offline_cap()


func _set_offline_resume_multiplier() -> void:
	ProjectSettings.set_setting(OFFLINE_KEYS + "exit_multiplier",
		_exit_multiplier if _offline_supported and _offline_enabled else 1.0)


func _save_exit_speed() -> void:
	if not _offline_supported:
		return
	var slot := String(ProjectSettings.get_setting(OFFLINE_KEYS + "active_slot", ""))
	# Closing the title screen before selecting a character preserves the
	# pending record for the last played character.
	var multiplier := _sanitize_speed(_speed_multiplier, 1.0)
	var recorded_at := int(Time.get_unix_time_from_system())
	if slot.is_empty():
		slot = String(ProjectSettings.get_setting(OFFLINE_KEYS + "exited_slot", ""))
		if slot.is_empty():
			return
		# No character was opened. Resave what startup consumed, not today's
		# settings or time; this was not a new exit from gameplay.
		multiplier = _exit_multiplier
		recorded_at = _exit_record_time
	var record := ConfigFile.new()
	record.set_value("exit", "slot", slot)
	record.set_value("exit", "multiplier", multiplier)
	record.set_value("exit", "unix_time", recorded_at)
	_save_config(record, EXIT_SPEED_PATH)


func _toggle_offline() -> void:
	_offline_enabled = not _offline_enabled
	_set_offline_resume_multiplier()
	_save_speed()
	_update_button()
	_write_runtime_status()
	print("SPEED_OFFLINE: follow_exit=", _offline_enabled)


func _record_offline_settlement() -> void:
	if not _offline_supported or not ProjectSettings.get_setting(OFFLINE_KEYS + "pending", false):
		return
	ProjectSettings.set_setting(OFFLINE_KEYS + "pending", false)
	var actual := float(ProjectSettings.get_setting(OFFLINE_KEYS + "actual_ms", 0.0))
	var requested := float(ProjectSettings.get_setting(OFFLINE_KEYS + "requested_ms", 0.0))
	var cap := float(ProjectSettings.get_setting(OFFLINE_KEYS + "cap_ms", 0.0))
	_offline_result = {
		"recorded_unix": int(Time.get_unix_time_from_system()),
		"actual_seconds": actual / 1000.0,
		"multiplier": float(ProjectSettings.get_setting(OFFLINE_KEYS + "multiplier", 1.0)),
		"requested_seconds": requested / 1000.0,
		"cap_seconds": cap / 1000.0,
		"target_seconds": minf(requested, cap) / 1000.0,
	}
	print("SPEED_OFFLINE: ", JSON.stringify(_offline_result))
	_write_runtime_status()


func _offline_description() -> String:
	if not _offline_supported:
		return "离线倍率未加载，结算按游戏原规则进行。"
	var cap_text := "原版（基础 24 小时）" if _cap_hours == 24 else "至少 %d 小时（保留游戏加成）" % _cap_hours
	var follow_text := "离线跟随已开启（F7 关闭）。" if _offline_enabled else "离线跟随已关闭（F7 开启）。"
	return follow_text + "\n离线时长上限： " + cap_text


func _exit_tree() -> void:
	_record_offline_settlement()
	_save_speed()
	_save_exit_speed()
	if _engine_ready and Engine.physics_ticks_per_second == _applied_ticks:
		Engine.physics_ticks_per_second = _base_ticks_per_second
	if _engine_ready and Engine.max_physics_steps_per_frame == _applied_steps:
		Engine.max_physics_steps_per_frame = _base_max_physics_steps


func _run_selftest() -> void:
	var failures: Array[String] = []
	for value in [-1.0, 0.0, 7.0, 100000.0, INF, NAN, "bad"]:
		if _sanitize_speed(value) != 2.0:
			failures.append("invalid multiplier accepted")
	for value in SPEEDS:
		if _sanitize_speed(value) != value:
			failures.append("supported multiplier rejected")
	if failures.is_empty():
		print("SPEED_MOD_SELFTEST: passed")
	else:
		print("SPEED_MOD_SELFTEST: failed ", failures)
		get_tree().quit(1)
