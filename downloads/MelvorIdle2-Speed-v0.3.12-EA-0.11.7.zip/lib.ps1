﻿$ErrorActionPreference = 'Stop'

function Get-MelvorUserDataDir { return (Join-Path $env:APPDATA 'Games By Malcs\Melvor Idle 2') }

function Enter-MelvorModLock {
    param([string]$GameDir)
    $path=Join-Path $GameDir '.melvor2_mod.lock'
    Assert-PlainPath $path
    try {return [IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
    catch {throw '另一个模组安装/卸载操作正在运行，或游戏目录无法写入，请稍后重试。'}
}

function Get-MelvorSteamLibraries {
    $registry = Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue
    $roots = @($registry.SteamPath, 'C:\Program Files (x86)\Steam', 'C:\Program Files\Steam', 'D:\Steam', 'E:\Steam')
    $libraries = foreach ($root in $roots | Select-Object -Unique) {
        if (-not $root -or -not [IO.Directory]::Exists($root)) { continue }
        $root
        $vdf = [IO.Path]::Combine($root, 'steamapps', 'libraryfolders.vdf')
        if (-not [IO.File]::Exists($vdf)) { continue }
        try {
            $content = Get-Content -LiteralPath $vdf -Raw -Encoding UTF8 -ErrorAction Stop
            foreach ($match in [regex]::Matches($content, '"path"\s+"([^"]+)"')) {
                $library = $match.Groups[1].Value.Replace('\\', '\')
                # Steam retains entries for disconnected disks in libraryfolders.vdf.
                if ([IO.Directory]::Exists($library)) { $library }
            }
        } catch {
            Write-Verbose ('无法读取 Steam 库清单，继续检查其他库：' + $vdf + '。' + $_.Exception.Message)
        }
    }
    $libraries | Select-Object -Unique
}

function Get-MelvorEaManifest {
    param([string]$GameDir)
    try {
        $directory = Get-Item -LiteralPath $GameDir -ErrorAction Stop
        $common = $directory.Parent
        if ($common.Name -ne 'common' -or $common.Parent.Name -ne 'steamapps') { return $null }
        $path = [IO.Path]::Combine($common.Parent.FullName, 'appmanifest_3218350.acf')
        if (-not [IO.File]::Exists($path)) { return $null }
        $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
        $name = [regex]::Match($content, '"installdir"\s+"([^"\r\n]+)"')
        if ($name.Success -and $name.Groups[1].Value -ieq $directory.Name) { return $content }
    } catch {
        Write-Verbose ('无法读取此目录的 EA 清单：' + $GameDir + '。' + $_.Exception.Message)
    }
    return $null
}

function Get-MelvorSteamBuildId {
    param([string]$GameDir)
    $manifest=Get-MelvorEaManifest $GameDir
    if($manifest) {
        $match=[regex]::Match($manifest,'"buildid"\s+"([^"\r\n]+)"')
        if($match.Success) {return $match.Groups[1].Value}
    }
    return $null
}

function Get-MelvorGameDir {
    param([string]$RequestedDir)
    if ($RequestedDir) {
        $candidate = $RequestedDir.Trim().Trim('"')
        $item = Get-Item -LiteralPath $candidate -ErrorAction SilentlyContinue
        if ($item -and $item.Name -ieq 'Melvor2.exe' -and -not $item.PSIsContainer) { $candidate = $item.DirectoryName }
        $exe = [IO.Path]::Combine($candidate, 'Melvor2.exe')
        if (-not [IO.File]::Exists($exe)) { throw "找不到 Melvor2.exe：$candidate" }
        $resolved = (Resolve-Path -LiteralPath $candidate).Path
        if ((Get-MelvorEaManifest $resolved) -or (Get-ModFileHash -LiteralPath $exe).Hash -eq '770b22a1c5bf37ab4e3bee0ba8b396a8008ecaa8d970270c3e9ed6d07ceffd3b') { return $resolved }
        throw '无法确认该目录属于 Steam EA（AppID 3218350）。请从 Steam 的“浏览本地文件”找到 EA 游戏目录。'
    }
    $found = foreach ($library in @(Get-MelvorSteamLibraries)) {
        try {
            $steamapps = [IO.Path]::Combine($library, 'steamapps')
            $path = [IO.Path]::Combine($steamapps, 'appmanifest_3218350.acf')
            if (-not [IO.File]::Exists($path)) { continue }
            $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
            $name = [regex]::Match($content, '"installdir"\s+"([^"\r\n]+)"')
            if (-not $name.Success -or $name.Groups[1].Value -match '[\\/:]' -or $name.Groups[1].Value -in @('.', '..')) { continue }
            $candidate = [IO.Path]::Combine($steamapps, 'common', $name.Groups[1].Value)
            if ([IO.File]::Exists([IO.Path]::Combine($candidate, 'Melvor2.exe'))) {
                (Resolve-Path -LiteralPath $candidate -ErrorAction Stop).Path
            }
        } catch {
            Write-Verbose ('跳过当前不可读取的 Steam 库：' + $library + '。' + $_.Exception.Message)
        }
    }
    $candidates = @($found | Sort-Object -Unique)
    if ($candidates.Count -eq 1) { return $candidates[0] }
    if ($candidates.Count -gt 1) { $candidates | ForEach-Object { Write-Host $_ } }
    $manual = Read-Host '请输入 Steam EA 的 Melvor2.exe 所在目录'
    if ($manual) { return Get-MelvorGameDir -RequestedDir $manual }
    throw '找不到 Melvor Idle 2 EA 游戏目录。'
}

function Get-ModFileHash {
    param([string]$LiteralPath,[string]$Algorithm='SHA256')
    if($Algorithm -ne 'SHA256') {throw 'Only SHA256 is supported.'}
    $crypto=[Security.Cryptography.SHA256]::Create();$stream=$null
    try {
        $stream=[IO.File]::OpenRead($LiteralPath)
        return [pscustomobject]@{Hash=[BitConverter]::ToString($crypto.ComputeHash($stream)).Replace('-','')}
    } finally {if($null -ne $stream) {$stream.Dispose()};$crypto.Dispose()}
}

function Assert-PackageFile {
    param([string]$Path,[string]$ExpectedHash)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "缺少文件: $Path" }
    if ((Get-ModFileHash -LiteralPath $Path -Algorithm SHA256).Hash -ne $ExpectedHash) { throw "文件校验失败: $Path" }
}

function Get-AutoloadValues {
    param([string]$Text,[string]$Name)
    $section = ''
    foreach ($line in ($Text -split '\r?\n')) {
        if ($line -cmatch '^\s*\[([^\]]+)\]\s*(?:;.*)?$') { $section=$Matches[1]; continue }
        if ($section -ceq 'autoload' -and $line -cmatch ('^\s*'+[regex]::Escape($Name)+'\s*=')) {
            if ($line -cnotmatch ('^\s*'+[regex]::Escape($Name)+'\s*=\s*"([^"]+)"\s*(?:;.*)?$')) { throw "无法解析 autoload 项 $Name，请检查 override.cfg。" }
            $Matches[1]
        }
    }
}

function Merge-AutoloadEntry {
    param([string]$ExistingText,[string]$Name,[string]$ManagedPath,[string]$Marker,[string[]]$AllowedExistingPaths=@())
    $allowed = @($ManagedPath,$ManagedPath.TrimStart('*'))+$AllowedExistingPaths+@($AllowedExistingPaths | ForEach-Object {$_.TrimStart('*')})
    foreach ($value in @(Get-AutoloadValues $ExistingText $Name)) {
        if ($value -notin $allowed) { throw "autoload 名称 $Name 已由其他模组使用，拒绝覆盖: $value" }
    }
    $lines=[Collections.Generic.List[string]]::new()
    if ($ExistingText) { foreach($line in ($ExistingText -split '\r?\n')) { $lines.Add($line) } }
    $section='';$indices=[Collections.Generic.List[int]]::new();$autoload=-1
    for($i=0;$i -lt $lines.Count;$i++) {
        if($lines[$i] -cmatch '^\s*\[([^\]]+)\]\s*(?:;.*)?$') { $section=$Matches[1];if($section -ceq 'autoload'){$autoload=$i};continue }
        if($section -ceq 'autoload' -and $lines[$i] -cmatch ('^\s*'+[regex]::Escape($Name)+'\s*=')) {$indices.Add($i)}
    }
    $managedLine=$Name+'="'+$ManagedPath+'"'
    if($indices.Count -gt 0) {$lines[$indices[0]]=$managedLine;for($i=$indices.Count-1;$i -ge 1;$i--){$lines.RemoveAt($indices[$i])}}
    elseif($autoload -ge 0) {$lines.Insert($autoload+1,$managedLine)}
    else {$lines.Add('');$lines.Add('[autoload]');$lines.Add($managedLine)}
    if(-not ($lines | Where-Object {$_ -eq $Marker})) {$lines.Insert(0,$Marker)}
    return (($lines -join "`r`n").TrimEnd()+"`r`n")
}

function Remove-AutoloadEntry {
    param([string]$ExistingText,[string]$Name,[string[]]$ManagedPaths,[string]$Marker)
    $result=[Collections.Generic.List[string]]::new();$section=''
    foreach($line in ($ExistingText -split '\r?\n')) {
        if($line -cmatch '^\s*\[([^\]]+)\]\s*(?:;.*)?$') {$section=$Matches[1]}
        if($line -eq $Marker) {continue}
        $remove=$false
        if($section -ceq 'autoload') {foreach($path in $ManagedPaths) {if($line -cmatch ('^\s*'+[regex]::Escape($Name)+'\s*=\s*"'+'\*?'+[regex]::Escape($path.TrimStart('*'))+'"\s*(?:;.*)?$')) {$remove=$true;break}}}
        if(-not $remove) {$result.Add($line)}
    }
    for($i=$result.Count-1;$i -ge 0;$i--) {
        if($result[$i] -cnotmatch '^\s*\[autoload\]\s*(?:;.*)?$') {continue}
        $next=$i+1
        while($next -lt $result.Count -and $result[$next].Trim() -eq '') {$next++}
        if($next -ge $result.Count -or $result[$next] -cmatch '^\s*\[') {$result.RemoveAt($i)}
    }
    $text=($result -join "`r`n").Trim()
    if($text) {return ($text+"`r`n")}
    return ''
}

function Merge-ZhModOverrideContent {
    param([string]$ExistingText,[string]$ManagedPath='*res://mods/melvor2_zh_cn/zh_mod.gd')
    Merge-AutoloadEntry $ExistingText 'ZhMod' $ManagedPath '; Melvor Idle 2 zh_CN mod - managed by installer' @('*res://mods/melvor2_zh_cn/zh_mod.gd','*user://zh_mod.gd')
}
function Remove-ZhModOverrideEntry {
    param([string]$ExistingText)
    Remove-AutoloadEntry $ExistingText 'ZhMod' @('*res://mods/melvor2_zh_cn/zh_mod.gd','*user://zh_mod.gd') '; Melvor Idle 2 zh_CN mod - managed by installer'
}

function Assert-PlainPath {
    param([string]$Path,[switch]$Recursive)
    $current=[IO.Path]::GetFullPath($Path)
    while($current) {
        if(Test-Path -LiteralPath $current) {
            if((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw "目标路径含目录链接，拒绝修改: $current"}
        }
        $parent=Split-Path $current -Parent
        if(-not $parent -or $parent -eq $current) {break}
        $current=$parent
    }
    if($Recursive -and (Test-Path -LiteralPath $Path -PathType Container)) {
        foreach($item in (Get-ChildItem -LiteralPath $Path -Recurse -Force)) {
            if($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw "模组目录含链接，拒绝递归修改: $($item.FullName)"}
        }
    }
}

function Remove-ModTarget {
    param([string]$Path,[string]$Root)
    $full=[IO.Path]::GetFullPath($Path);$prefix=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
    if(-not $full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {throw "目标超出允许目录: $full"}
    Assert-PlainPath $full -Recursive
    if(Test-Path -LiteralPath $full) {Remove-Item -LiteralPath $full -Recurse -Force}
}

function Write-ModAtomicText {
    param([string]$Path,[string]$Text)
    $temporary=$Path+'.new_'+[guid]::NewGuid().ToString('N')
    try {
        [IO.File]::WriteAllText($temporary,$Text,(New-Object Text.UTF8Encoding($false)))
        if(Test-Path -LiteralPath $Path) {[IO.File]::Replace($temporary,$Path,[System.Management.Automation.Language.NullString]::Value)}
        else {[IO.File]::Move($temporary,$Path)}
    } finally {if(Test-Path -LiteralPath $temporary) {Remove-Item -LiteralPath $temporary -Force}}
}

function Set-SpeedModButtonVisible {
    $path=Join-Path (Get-MelvorUserDataDir) 'melvor2_speed.cfg'
    if(-not (Test-Path -LiteralPath $path -PathType Leaf)) {return}
    $text=Get-Content -LiteralPath $path -Raw -Encoding UTF8
    $script:melvorInSpeed=$false
    $updated=[regex]::Replace($text,'(?m)^.*$',{
        param($match)
        $line=$match.Value
        if($line -match '^\s*\[([^\]]+)\]') {$script:melvorInSpeed=($Matches[1] -eq 'speed')}
        if($script:melvorInSpeed -and $line -match '^[ \t]*button_visible[ \t]*=[ \t]*(true|false)[ \t]*\r?$') {
            return [regex]::Replace($line,'(=[ \t]*)(?:true|false)','$1true')
        }
        return $line
    })
    Remove-Variable -Name melvorInSpeed -Scope Script -ErrorAction SilentlyContinue
    if($updated -ne $text) {Write-ModAtomicText $path $updated}
}

function Get-ModOverrideText {
    param([string]$Path)
    if(Test-Path -LiteralPath $Path) {
        if(-not (Test-Path -LiteralPath $Path -PathType Leaf)) {throw "配置路径不是文件: $Path"}
        return Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    }
    return ''
}

function Assert-ModOwned {
    param([string]$ModDir,[string]$ModId)
    Assert-PlainPath $ModDir -Recursive
    if(Test-Path -LiteralPath $ModDir) {
        $owned=$false
        try {$owned=(Get-Content -LiteralPath (Join-Path $ModDir 'version.json') -Raw -Encoding UTF8 | ConvertFrom-Json).id -eq $ModId} catch {}
        if(-not $owned) {throw "目录不属于本模组，拒绝修改: $ModDir"}
    }
}

function Test-LegacyZhOwned {
    $user=Get-MelvorUserDataDir;$script=Join-Path $user 'zh_mod.gd';$marker=Join-Path $user 'zh_mod_force_user'
    if(Test-Path -LiteralPath $script -PathType Leaf) {return (Get-Content -LiteralPath $script -Raw -Encoding UTF8) -cmatch 'ZH_MOD: autoload ready'}
    return (Test-Path -LiteralPath $marker -PathType Leaf)
}

function Invoke-ModTransaction {
    param([string]$GameDir,[string[]]$Paths,[scriptblock]$Action)
    Assert-PlainPath $GameDir
    $transaction=Join-Path $GameDir ('.melvor2_transaction_'+[guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $transaction | Out-Null
    $snapshots=@();$clean=$false;$actionStarted=$false
    try {
        foreach($path in ($Paths | Select-Object -Unique)) {
            Assert-PlainPath $path -Recursive
            $exists=Test-Path -LiteralPath $path
            $copy=Join-Path $transaction ('snapshot_'+$snapshots.Count)
            $snapshots+=@{Path=$path;Backup=$copy;Exists=$exists}
            if($exists) {Copy-Item -LiteralPath $path -Destination $copy -Recurse -Force}
        }
        $actionStarted=$true
        & $Action $transaction
        $clean=$true
    } catch {
        $original=$_;$rollbackErrors=@()
        foreach($snapshot in $(if($actionStarted){$snapshots}else{@()})) {
            try {
                # If copying a snapshot failed before a backup existed, no action ran.
                if($snapshot.Exists -and -not (Test-Path -LiteralPath $snapshot.Backup)) {continue}
                $same=$false
                if($snapshot.Exists -and (Test-Path -LiteralPath $snapshot.Backup -PathType Leaf) -and (Test-Path -LiteralPath $snapshot.Path -PathType Leaf)) {
                    $same=(Get-ModFileHash -LiteralPath $snapshot.Backup).Hash -eq (Get-ModFileHash -LiteralPath $snapshot.Path).Hash
                }
                if($same) {continue}
                Remove-ModTarget $snapshot.Path (Split-Path $snapshot.Path -Parent)
                if($snapshot.Exists) {Copy-Item -LiteralPath $snapshot.Backup -Destination $snapshot.Path -Recurse -Force}
            } catch {$rollbackErrors+= $_.Exception.Message}
        }
        if($rollbackErrors.Count) {throw "操作失败: $($original.Exception.Message)。回滚未完成，备份保留在 $transaction。$($rollbackErrors -join '；')"}
        $clean=$true
        throw $original
    } finally {
        if($clean -and (Test-Path -LiteralPath $transaction)) {
            try {Remove-ModTarget $transaction $GameDir} catch {Write-Warning "操作已完成，临时备份保留在 $transaction"}
        }
    }
}

$script:SpeedOfflineOriginal = 'ad27d7141953bb76927f9e74992d629106455c7c017f3d0138ac8268ccf9796c'
$script:SpeedOfflinePatched = '3e05d7dd43eb8418269bb024c1795d3d5a452e32c72ed204d6f72bf89e39fe6e'


function Get-SpeedNativeState {
    param([string]$GameDir)
    $library=Join-Path $GameDir 'data_GamesByMalcs.Melvor2_windows_x86_64\GamesByMalcs.Melvor2.dll'
    $backup=$library+'.speedmod-26886380.original'
    $hash=''
    if(Test-Path -LiteralPath $library -PathType Leaf) {
        $hash=(Get-ModFileHash -LiteralPath $library).Hash
    }
    return [pscustomobject]@{ Library=$library; Backup=$backup; Hash=$hash }
}

function Expand-SpeedNativeDelta {
    param([string]$Source,[string]$Delta,[string]$Destination,$Patch)
    Assert-PackageFile $Source $script:SpeedOfflineOriginal
    Assert-PackageFile $Delta $Patch.patch_sha256
    $original=[IO.File]::ReadAllBytes($Source)
    if($original.Length -ne $Patch.source_size -or (Get-Item -LiteralPath $Delta).Length -ne $Patch.patch_size) {
        throw '离线补丁长度校验失败。'
    }

    $reader=[IO.BinaryReader]::new([IO.File]::OpenRead($Delta))
    try {
        $signature=[Text.Encoding]::ASCII.GetString($reader.ReadBytes(4))
        $length=$reader.ReadInt32()
        $count=$reader.ReadInt32()
        if($signature -cne 'M2D1' -or $length -ne $Patch.patched_size -or $count -ne $Patch.command_count) {
            throw '离线补丁头校验失败。'
        }
        $stream=[IO.File]::Open($Destination,[IO.FileMode]::CreateNew)
        try {
            for($i=0; $i -lt $count; $i++) {
                $offset=$reader.ReadInt32()
                $bytes=$reader.ReadInt32()
                if($bytes -le 0 -or $stream.Position+$bytes -gt $length) {throw '离线补丁目标范围无效。'}
                if($offset -eq -1) {
                    $literal=$reader.ReadBytes($bytes)
                    if($literal.Length -ne $bytes) {throw '离线补丁数据不完整。'}
                    $stream.Write($literal,0,$bytes)
                } else {
                    if($offset -lt 0 -or [long]$offset+$bytes -gt $original.Length) {throw '离线补丁源范围无效。'}
                    $stream.Write($original,$offset,$bytes)
                }
            }
            if($stream.Position -ne $length -or $reader.BaseStream.Position -ne $reader.BaseStream.Length) {
                throw '离线补丁输出长度不匹配。'
            }
        } finally {$stream.Dispose()}
    } finally {$reader.Dispose()}
    Assert-PackageFile $Destination $script:SpeedOfflinePatched
}

function Install-SpeedNativePatch {
    param($State,[string]$PackageRoot,[string]$Transaction,$Patch)
    if($Patch.source_sha256 -ne $script:SpeedOfflineOriginal -or $Patch.patched_sha256 -ne $script:SpeedOfflinePatched) {
        throw '离线补丁清单与安装器不匹配。'
    }
    $staged=Join-Path $Transaction 'offline_native.new'
    $source=$State.Library
    Expand-SpeedNativeDelta -Source $source -Delta (Join-Path $PackageRoot 'offline_delta.bin') -Destination $staged -Patch $Patch
    if(-not (Test-Path -LiteralPath $State.Backup -PathType Leaf)) {
        Copy-Item -LiteralPath $source -Destination $State.Backup
    }
    Assert-PackageFile $State.Backup $script:SpeedOfflineOriginal
    Assert-PackageFile $State.Library $State.Hash
    [IO.File]::Replace($staged,$State.Library,[System.Management.Automation.Language.NullString]::Value)
    Assert-PackageFile $State.Library $script:SpeedOfflinePatched
}

function Get-SpeedNativeDiagnostic {
    param([string]$GameDir)
    $state=Get-SpeedNativeState $GameDir
    if($state.Hash -eq $script:SpeedOfflinePatched) {
        if(-not (Test-Path -LiteralPath $state.Backup -PathType Leaf) -or
            (Get-ModFileHash -LiteralPath $state.Backup).Hash -ne $script:SpeedOfflineOriginal) {
            throw '离线补丁已生效，但原始 DLL 备份缺失或校验失败。'
        }
        return '离线 DLL 和原版备份校验通过。'
    }
    if($state.Hash -eq $script:SpeedOfflineOriginal) {
        return '当前使用原版 DLL，重新安装此版加速 Mod 可接入离线倍率。'
    }
    return '当前 DLL 与已验证版本不同，本机按原生离线结算。'
}

function Install-MelvorMod {
    param([string]$PackageRoot,[string]$GameDir,[string]$ModId,[string]$Name,[switch]$LegacyLayout)
    $manifest=Get-Content -LiteralPath (Join-Path $PackageRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $scriptName=if($ModId -eq 'melvor2_zh_cn') {'zh_mod.gd'} else {'speed_mod.gd'}
    $files=Join-Path $PackageRoot 'files';$prefix=[IO.Path]::GetFullPath($files)+'\'
    foreach($entry in $manifest.files.PSObject.Properties) {
        $source=[IO.Path]::GetFullPath((Join-Path $files $entry.Name.Replace('/','\')))
        if(-not $source.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {throw '清单包含越界路径。'}
        Assert-PackageFile $source $entry.Value.sha256
        if((Get-Item -LiteralPath $source).Length -ne $entry.Value.size) {throw "文件大小校验失败: $source"}
    }
    $modDir=Join-Path $GameDir ('mods\'+$ModId);Assert-ModOwned $modDir $ModId
    $override=Join-Path $GameDir 'override.cfg';$oldText=Get-ModOverrideText $override
    $managed='*res://mods/'+$ModId+'/'+$scriptName
    $marker=if($Name -eq 'ZhMod') {'; Melvor Idle 2 zh_CN mod - managed by installer'} else {'; Melvor Idle 2 Speed Mod - managed by installer'}
    $aliases=@($managed);$legacyPaths=@();$ownedLegacy=$false
    if($Name -eq 'ZhMod') {
        $aliases+='*user://zh_mod.gd';$user=Get-MelvorUserDataDir
        $legacyPaths=@('zh_mod.gd','zh.pck','zh_mod_force_user') | ForEach-Object {Join-Path $user $_}
        $ownedLegacy=Test-LegacyZhOwned
        if($LegacyLayout) {
            if(-not $ownedLegacy -and @($legacyPaths | Where-Object {Test-Path -LiteralPath $_}).Count) {throw 'AppData 已有来源不明的同名文件，拒绝覆盖。'}
            $managed='*user://zh_mod.gd'
        }
    }
    $merged=Merge-AutoloadEntry $oldText $Name $managed $marker $aliases
    $paths=@($modDir,$override)
    $speedConfig=Join-Path (Get-MelvorUserDataDir) 'melvor2_speed.cfg'
    if($Name -eq 'SpeedMod') {$paths+=$speedConfig}
    if($ownedLegacy -or $LegacyLayout) {$paths+=$legacyPaths}
    $installOffline=$false
    if($Name -eq 'SpeedMod' -and $manifest.offline_patch) {
        $native=Get-SpeedNativeState $GameDir
        if($native.Hash -eq $script:SpeedOfflinePatched) {
            Assert-PackageFile $native.Backup $script:SpeedOfflineOriginal
        } elseif($native.Hash -eq $script:SpeedOfflineOriginal) {
            $installOffline=$true
            $paths+=@($native.Library,$native.Backup)
        } else {
            Write-Warning '当前 EA DLL 哈希与离线调试版不同。继续安装在线加速。'
        }
    }
    Invoke-ModTransaction $GameDir $paths {
        param($transaction)
        if($installOffline) {Install-SpeedNativePatch $native $PackageRoot $transaction $manifest.offline_patch}
        if($LegacyLayout) {
            New-Item -ItemType Directory -Path (Get-MelvorUserDataDir) -Force | Out-Null
            foreach($leaf in @('zh_mod.gd','zh.pck')) {Copy-Item -LiteralPath (Join-Path $files ('mods\'+$ModId+'\'+$leaf)) -Destination (Join-Path (Get-MelvorUserDataDir) $leaf) -Force}
            [IO.File]::WriteAllText((Join-Path (Get-MelvorUserDataDir) 'zh_mod_force_user'),'')
        } else {
            $stage=Join-Path $transaction 'payload';New-Item -ItemType Directory -Path $stage | Out-Null
            foreach($entry in $manifest.files.PSObject.Properties) {
                if(-not $entry.Name.StartsWith('mods/'+$ModId+'/')) {continue}
                $leaf=$entry.Name.Substring(('mods/'+$ModId+'/').Length)
                if($leaf -cmatch '[\\/]') {throw '本包不支持嵌套的载荷路径。'}
                Copy-Item -LiteralPath (Join-Path $files $entry.Name.Replace('/','\')) -Destination (Join-Path $stage $leaf)
                Assert-PackageFile (Join-Path $stage $leaf) $entry.Value.sha256
            }
            New-Item -ItemType Directory -Path (Split-Path $modDir -Parent) -Force | Out-Null
            Remove-ModTarget $modDir (Split-Path $modDir -Parent)
            Move-Item -LiteralPath $stage -Destination $modDir
        }
        Write-ModAtomicText $override $merged
        if($Name -eq 'SpeedMod') {Set-SpeedModButtonVisible}
        if(-not $LegacyLayout -and $ownedLegacy) {foreach($path in $legacyPaths) {Remove-ModTarget $path (Get-MelvorUserDataDir)}}
    }
}

function Uninstall-MelvorMod {
    param([string]$GameDir,[string]$ModId,[string]$Name)
    $modDir=Join-Path $GameDir ('mods\'+$ModId);Assert-ModOwned $modDir $ModId
    $override=Join-Path $GameDir 'override.cfg';$text=Get-ModOverrideText $override
    $paths=@($modDir,$override);$legacy=@()
    if($Name -eq 'ZhMod') {
        $cleaned=Remove-ZhModOverrideEntry $text
        if(Test-LegacyZhOwned) {$legacy=@('zh_mod.gd','zh.pck','zh_mod_force_user') | ForEach-Object {Join-Path (Get-MelvorUserDataDir) $_};$paths+=$legacy}
    } else {$cleaned=Remove-AutoloadEntry $text $Name @('*res://mods/melvor2_speed/speed_mod.gd') '; Melvor Idle 2 Speed Mod - managed by installer'}
    $restoreNative=$false
    $ownedNativeBackup=$false
    if($Name -eq 'SpeedMod') {
        $native=Get-SpeedNativeState $GameDir
        $restoreNative=$native.Hash -eq $script:SpeedOfflinePatched
        if(Test-Path -LiteralPath $native.Backup -PathType Leaf) {
            $ownedNativeBackup=(Get-ModFileHash -LiteralPath $native.Backup).Hash -eq $script:SpeedOfflineOriginal
        }
        if($restoreNative -and -not $ownedNativeBackup) {throw '未找到校验通过的原版 DLL 备份。请先在 Steam 验证游戏文件完整性。'}
        if($restoreNative) {$paths+=$native.Library}
        if($ownedNativeBackup) {$paths+=$native.Backup}
    }
    Invoke-ModTransaction $GameDir $paths {
        param($transaction)
        if($restoreNative) {
            $original=Join-Path $transaction 'offline_native.restore'
            Copy-Item -LiteralPath $native.Backup -Destination $original
            Assert-PackageFile $original $script:SpeedOfflineOriginal
            [IO.File]::Replace($original,$native.Library,[System.Management.Automation.Language.NullString]::Value)
            Assert-PackageFile $native.Library $script:SpeedOfflineOriginal
        }
        if($ownedNativeBackup) {Remove-ModTarget $native.Backup (Split-Path $native.Backup -Parent)}
        if($cleaned.Trim()) {Write-ModAtomicText $override $cleaned} else {Remove-ModTarget $override $GameDir}
        Remove-ModTarget $modDir (Split-Path $modDir -Parent)
        foreach($path in $legacy) {Remove-ModTarget $path (Get-MelvorUserDataDir)}
    }
    $mods=Join-Path $GameDir 'mods'
    if((Test-Path -LiteralPath $mods) -and -not (Get-ChildItem -LiteralPath $mods -Force | Select-Object -First 1)) {Remove-Item -LiteralPath $mods}
}

function Test-MelvorModInstallation {
    param([string]$PackageRoot,[string]$GameDir,[string]$ModId,[string]$Name,[switch]$AllowUnsupportedVersion)
    $manifest=Get-Content -LiteralPath (Join-Path $PackageRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if(-not $AllowUnsupportedVersion -and (Get-MelvorSteamBuildId $GameDir) -ne $manifest.steam_buildid) {throw '游戏版本不匹配。'}
    $values=@(Get-AutoloadValues (Get-ModOverrideText (Join-Path $GameDir 'override.cfg')) $Name)
    $scriptName=if($Name -eq 'ZhMod') {'zh_mod.gd'} else {'speed_mod.gd'}
    $normal='*res://mods/'+$ModId+'/'+$scriptName
    if($values.Count -ne 1 -or ($values[0] -ne $normal -and -not ($Name -eq 'ZhMod' -and $values[0] -eq '*user://zh_mod.gd'))) {throw "autoload 项 $Name 缺失、重复或路径不匹配。"}
    $legacy=$values[0] -eq '*user://zh_mod.gd';$user=Get-MelvorUserDataDir
    if($Name -eq 'ZhMod' -and $legacy -ne (Test-Path -LiteralPath (Join-Path $user 'zh_mod_force_user'))) {throw '汉化布局标志与实际配置不一致。'}
    foreach($entry in $manifest.files.PSObject.Properties) {
        if($entry.Name -eq 'override.cfg') {continue}
        if($legacy) {
            $leaf=Split-Path $entry.Name -Leaf
            if($leaf -eq 'version.json') {continue}
            $target=Join-Path $user $leaf
        } else {$target=Join-Path $GameDir $entry.Name.Replace('/','\')}
        Assert-PackageFile $target $entry.Value.sha256
        if((Get-Item -LiteralPath $target).Length -ne $entry.Value.size) {throw "文件大小校验失败: $target"}
    }
    if($Name -eq 'SpeedMod' -and $manifest.offline_patch) {Write-Host (Get-SpeedNativeDiagnostic $GameDir)}
    Write-Host "安装文件检查通过: $($manifest.version)" -ForegroundColor Green
    Write-Host ("游戏目录: "+$GameDir)
    Write-Host ("Steam Build: "+(Get-MelvorSteamBuildId $GameDir)+"；已实测 Build: "+$manifest.steam_buildid)
    Write-Host '文件检查不代表游戏已加载脚本。请重启游戏，再运行“运行诊断.bat”查看实际加载记录。' 
}
